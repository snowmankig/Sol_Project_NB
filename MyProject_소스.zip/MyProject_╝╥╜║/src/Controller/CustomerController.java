package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.CustomerVO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class CustomerController implements Initializable {

	// ���̺� �� ����
	@FXML
	private TableView<CustomerVO> tableView = new TableView<>();

	// �ؽ�Ʈ �ʵ� ����
	@FXML
	private TextField txt_CustomerCode;
	@FXML
	private TextField txt_CustomerName;
	@FXML
	private TextField txt_CustomerAge;
	@FXML
	private TextField txt_CustomerGender;
	@FXML
	private TextField txt_CustomerTel;
	@FXML
	private TextField txt_CustomerEmail;
	@FXML
	private TextArea txt_CustomerRemarks;
	@FXML
	private TextField txt_CustomerSearch;

	// ��ư ����
	@FXML
	private Button btn_Customer_Add;
	@FXML
	private Button btn_Customer_Edit;
	@FXML
	private Button btn_Customer_Delete;
	@FXML
	private Button btn_Customer_Close;
	@FXML
	private Button btn_Customer_Search;
	@FXML
	private Button btn_Customer_Reset;

	CustomerVO customer = new CustomerVO();
	ObservableList<CustomerVO> data = FXCollections.observableArrayList();
	ObservableList<CustomerVO> selectCustomer = null; // ���̺����� ������ ���� ����
	int selectedIndex; // ���̺����� ������ ���� ���� �ε��� ����

	int customerCode; // ���� ���̺����� ���� �� �˻��� ���� ������ �����ڵ� ����

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// ��ư�� �׼� ���ٽ�Ÿ�� (������)
		btn_Customer_Add.setOnAction(event -> HandlerBtn_Customer_AddAction(event));
		btn_Customer_Edit.setOnAction(event -> HandlerBtn_Customer_EditAction(event));
		btn_Customer_Delete.setOnAction(event -> HandlerBtn_Customer_DeleteAction(event));
		btn_Customer_Close.setOnAction(event -> HandlerBtn_Customer_CloseAction(event));
		btn_Customer_Search.setOnAction(event -> HandlerBtn_Customer_SearchAction(event));
		btn_Customer_Reset.setOnAction(event -> HandlerBtn_Customer_ResetAction(event));

		// ���̺� �� �÷��̸� ����
		TableColumn colCustomerCode = new TableColumn("�����ڵ�");
		colCustomerCode.setMaxWidth(80);
		colCustomerCode.setStyle("-fx-allignment: CENTER");
		colCustomerCode.setCellValueFactory(new PropertyValueFactory<>("customerCode"));

		TableColumn colCustomerName = new TableColumn("�̸�");
		colCustomerName.setMaxWidth(80);
		colCustomerName.setStyle("-fx-allignment: CENTER");
		colCustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));

		TableColumn colCustomerAge = new TableColumn("����");
		colCustomerAge.setMaxWidth(80);
		colCustomerAge.setStyle("-fx-allignment: CENTER");
		colCustomerAge.setCellValueFactory(new PropertyValueFactory<>("customerAge"));

		TableColumn colCustomerGender = new TableColumn("����");
		colCustomerGender.setMaxWidth(80);
		colCustomerGender.setStyle("-fx-allignment: CENTER");
		colCustomerGender.setCellValueFactory(new PropertyValueFactory<>("customerGender"));

		TableColumn colCustomerTel = new TableColumn("��ȣ");
		colCustomerTel.setMinWidth(80);
		colCustomerTel.setStyle("-fx-allignment: CENTER");
		colCustomerTel.setCellValueFactory(new PropertyValueFactory<>("customerTel"));

		TableColumn colCustomerEmail = new TableColumn("E-Mail");
		colCustomerEmail.setMinWidth(80);
		colCustomerEmail.setStyle("-fx-allignment: CENTER");
		colCustomerEmail.setCellValueFactory(new PropertyValueFactory<>("customerEmail"));

		TableColumn colCustomerRemarks = new TableColumn("���");
		colCustomerRemarks.setMinWidth(200);
		colCustomerRemarks.setStyle("-fx-allignment: CENTER");
		colCustomerRemarks.setCellValueFactory(new PropertyValueFactory<>("customerRemarks"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colCustomerCode, colCustomerName, colCustomerAge, colCustomerGender,
				colCustomerTel, colCustomerEmail, colCustomerRemarks);

		// ���� ��ü ����
		totalList();

		// ���̺� �信�� ������ ���� ���콺 Ŭ�� 
		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {

				try {
					selectCustomer = tableView.getSelectionModel().getSelectedItems();
					selectedIndex = tableView.getSelectionModel().getSelectedIndex();
					customerCode = selectCustomer.get(0).getCustomerCode();

					txt_CustomerCode.setText(selectCustomer.get(0).getCustomerCode() + "");
					txt_CustomerName.setText(selectCustomer.get(0).getCustomerName());
					txt_CustomerAge.setText(selectCustomer.get(0).getCustomerAge());
					txt_CustomerGender.setText(selectCustomer.get(0).getCustomerGender());
					txt_CustomerTel.setText(selectCustomer.get(0).getCustomerTel());
					txt_CustomerEmail.setText(selectCustomer.get(0).getCustomerEmail());
					txt_CustomerRemarks.setText(selectCustomer.get(0).getCustomerRemarks());

					txt_CustomerCode.setDisable(true);

				} catch (Exception e) {

				}
			}

		});

	}

	// ���� ��� ��ư �׼�
	public void HandlerBtn_Customer_AddAction(ActionEvent event) {

		data.removeAll(data);
		CustomerVO cVo = null;
		CustomerDAO cDao = null;

		try {

			cVo = new CustomerVO(Integer.parseInt(txt_CustomerCode.getText()), txt_CustomerName.getText(),
					txt_CustomerAge.getText(), txt_CustomerGender.getText(), txt_CustomerTel.getText(),
					txt_CustomerEmail.getText(), txt_CustomerRemarks.getText());

			cDao = new CustomerDAO();
			cDao.getCustomerregiste(cVo);

			if (cDao != null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� �Է�");
				alert.setHeaderText(txt_CustomerName.getText() + " ������ ���������� �߰��Ǿ����ϴ�..");
				alert.setContentText("���� ���������� �Է��ϼ���");
				alert.showAndWait();

				txt_CustomerCode.clear();
				txt_CustomerName.clear();
				txt_CustomerAge.clear();
				txt_CustomerGender.clear();
				txt_CustomerTel.clear();
				txt_CustomerEmail.clear();
				txt_CustomerRemarks.clear();

				totalList();
			}

		} catch (Exception e1) {

			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�������� �Է�");
			alert.setHeaderText("���������� ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}

	}

	// ���� ���� ��ư �׼� -> ��� �ۼ��� �����ؾ��� 11.8-10:20
	public void HandlerBtn_Customer_EditAction(ActionEvent event) {
		CustomerVO cVo = null;
		CustomerDAO cDao = null;

		try {

			cVo = new CustomerVO(Integer.parseInt(txt_CustomerCode.getText()), txt_CustomerName.getText(),
					txt_CustomerAge.getText(), txt_CustomerGender.getText(), txt_CustomerTel.getText(),
					txt_CustomerEmail.getText(), txt_CustomerRemarks.getText());
			cDao = new CustomerDAO();
			cDao.getCustomerUpdate(cVo, cVo.getCustomerCode());
			data.removeAll(data);

			totalList();

			txt_CustomerCode.clear();
			txt_CustomerName.clear();
			txt_CustomerAge.clear();
			txt_CustomerGender.clear();
			txt_CustomerTel.clear();
			txt_CustomerEmail.clear();
			txt_CustomerRemarks.clear();

			txt_CustomerCode.setDisable(false);

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� ���� ����");
			alert.setHeaderText("�����Ǵ� ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}

	}

	// ���� ���� ��ư �׼�
	public void HandlerBtn_Customer_DeleteAction(ActionEvent event) {
		CustomerDAO cDao = null;
		cDao = new CustomerDAO();

		try {
			cDao.getCustomerDelete(customerCode);
			data.removeAll(data);
			totalList();
			HandlerBtn_Customer_ResetAction(event);

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	// �ݱ� ��ư �׼�
	public void HandlerBtn_Customer_CloseAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btn_Customer_Close.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}

	}

	// ���� �˻� ��ư �׼�
	public void HandlerBtn_Customer_SearchAction(ActionEvent event) {

		CustomerVO cVo = new CustomerVO();
		CustomerDAO cDao = null;
		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txt_CustomerSearch.getText().trim();
			cDao = new CustomerDAO();
			cVo = cDao.getCustomerCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� ���� �˻�");
				alert.setHeaderText("������ �̸��� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (cVo != null)) {
				ArrayList<String> title;
				ArrayList<CustomerVO> list;
				
				title = cDao.getColumnName();
				int columnCount = title.size();
				
				list = cDao.getCustomerTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];
				
				if (cVo.getCustomerName().equals(searchName)) {
					txt_CustomerSearch.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						cVo = list.get(index);
						if (cVo.getCustomerName().equals(searchName)) {
							data.add(cVo);
							searchResult = true;

						}

					}
				}
			}
			if (!searchResult) {
				txt_CustomerSearch.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���� �˻�");
				alert.setHeaderText(searchName + " ���� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();
				
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("���� ���� �˻� ����");
			alert.setHeaderText("���� ���� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();


		}

	}

	// ���� �ʱ�ȭ
	public void HandlerBtn_Customer_ResetAction(ActionEvent event) {

		txt_CustomerCode.clear();
		txt_CustomerName.clear();
		txt_CustomerAge.clear();
		txt_CustomerGender.clear();
		txt_CustomerTel.clear();
		txt_CustomerEmail.clear();
		txt_CustomerRemarks.clear();
		txt_CustomerSearch.clear();
		
	
		
		data.removeAll(data);
		totalList();
		txt_CustomerCode.setDisable(false);

	}

	// ���� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		CustomerDAO cDao = new CustomerDAO();
		CustomerVO cVo = null;
		ArrayList<String> title;
		ArrayList<CustomerVO> list;

		title = cDao.getColumnName();
		int columnCount = title.size();

		list = cDao.getCustomerTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			cVo = list.get(index);
			data.add(cVo);
		}

	}

}
