package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.CustomerVO;
import Model.ItemInfoVO;
import Model.ItemStockVO;
import Model.OrderVO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class OrderController implements Initializable {

	// ���̺��� ����
	@FXML
	private TableView<OrderVO> tableView = new TableView<>();

	// ��ư ����
	@FXML
	private Button btn_Order_TotalList; // ��ü �ֹ� Ȯ��
	@FXML
	private Button btn_Order_AddView; // �ֹ���� ��ư
	@FXML
	private Button btn_Order_Add_In; // �԰� ��ư

	@FXML
	private Button btn_Order_Add_Delete; // �԰� ��� ��ư

	@FXML
	private Button btn_Order_Edit; // �ֹ����� ��ư

	@FXML
	private Button btn_Order_Delete; // �ֹ���� ��ư

	@FXML
	private Button btn_Order_Exit; // ���� ��ư

	@FXML
	private Button btn_Order_Search; // �˻� ��ư

	// �ؽ�Ʈ �ʵ� ����
	@FXML
	private TextField txt_Order_Date;
	@FXML
	private TextField txt_Order_Code;
	@FXML
	private TextField txt_Order_GoodsCode;
	@FXML
	private TextField txt_Order_GoodsName;
	@FXML
	private TextField txt_Order_GoodsQuantity;
	@FXML
	private TextField txt_Order_GoodsPrice;
	@FXML
	private TextArea txt_Order_GoodsRemarks;
	@FXML
	private TextField txt_Order_Search;

	OrderVO order = new OrderVO();
	ObservableList<OrderVO> data = FXCollections.observableArrayList();
	ObservableList<OrderVO> selectOrder = null; // ���̺����� ������ ���� ����

	ObservableList<ItemStockVO> Adddata = FXCollections.observableArrayList();
	ObservableList<ItemStockVO> AddOrder = null; // ���̺����� ������ ���� ����

	int selectedIndex; // ���̺����� ������ �ֹ� ���� �ε��� ����
	int order_Code; // �ֹ� ���̺����� ���� �� �˻��� ���� ������ �ֹ���ǰ�ڵ� ����
	int order_GoodsCode; // �ֹ� ���̺����� ���� �� �˻��� ���� ������ �ֹ���ǰ�ڵ� ����
	int st_goodsCode;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// ��ư �ʱ� ����
		btn_Order_Edit.setDisable(true);
		btn_Order_Delete.setDisable(true);
		btn_Order_Add_In.setDisable(true);
		btn_Order_Add_Delete.setDisable(true);

		// ��ư�� �׼� ���ٽ�Ÿ�� (������)
		btn_Order_AddView.setOnAction(event -> handlerBtn_Order_AddViewAction(event));
		btn_Order_Edit.setOnAction(event -> handlerBtn_Order_EditAction(event));
		btn_Order_Delete.setOnAction(event -> handlerBtn_Order_DeleteAction(event));
		btn_Order_Exit.setOnAction(event -> handlerBtn_Order_ExitAction(event));
		btn_Order_TotalList.setOnAction(event -> handlerBtn_Order_TotalListAction(event));
		btn_Order_Search.setOnAction(event -> handlerBtn_Order_SearchAction(event));

		// �԰� �� �԰� ���
		btn_Order_Add_In.setOnMouseClicked(event -> handlerBtn_Order_Add_InAction(event));
		btn_Order_Add_Delete.setOnMouseClicked(event -> handlerBtn_Order_Add_DeleteAction(event));

		// order main���̺� �� �÷��̸� ����
		TableColumn colOrder_Date = new TableColumn("�ֹ�����");
		colOrder_Date.setMinWidth(200);
		colOrder_Date.setStyle("-fx-allignment: CENTER");
		colOrder_Date.setCellValueFactory(new PropertyValueFactory<>("order_Date"));

		TableColumn colOrder_Code = new TableColumn("�ֹ���ȣ");
		colOrder_Code.setMinWidth(100);
		colOrder_Code.setStyle("-fx-allignment: CENTER");
		colOrder_Code.setCellValueFactory(new PropertyValueFactory<>("order_Code"));

		TableColumn colOrder_GoodsCode = new TableColumn("��ǰ�ڵ�");
		colOrder_GoodsCode.setMinWidth(100);
		colOrder_GoodsCode.setStyle("-fx-allignment: CENTER");
		colOrder_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("order_GoodsCode"));

		TableColumn colOrder_GoodsName = new TableColumn("��ǰ��");
		colOrder_GoodsName.setMinWidth(150);
		colOrder_GoodsName.setStyle("-fx-allignment: CENTER");
		colOrder_GoodsName.setCellValueFactory(new PropertyValueFactory<>("order_GoodsName"));

		TableColumn colOrder_GoodsQuantity = new TableColumn("��ǰ����");
		colOrder_GoodsQuantity.setMaxWidth(80);
		colOrder_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colOrder_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("order_GoodsQuantity"));

		TableColumn colOrder_GoodsPrice = new TableColumn("��ǰ�ܰ�");
		colOrder_GoodsPrice.setMinWidth(100);
		colOrder_GoodsPrice.setStyle("-fx-allignment: CENTER");
		colOrder_GoodsPrice.setCellValueFactory(new PropertyValueFactory<>("order_GoodsPrice"));

		TableColumn colOrder_GoodsRemarks = new TableColumn("���");
		colOrder_GoodsRemarks.setMinWidth(200);
		colOrder_GoodsRemarks.setStyle("-fx-allignment: CENTER");
		colOrder_GoodsRemarks.setCellValueFactory(new PropertyValueFactory<>("order_GoodsRemarks"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colOrder_Date, colOrder_Code, colOrder_GoodsCode, colOrder_GoodsName,
				colOrder_GoodsQuantity, colOrder_GoodsPrice, colOrder_GoodsRemarks);

		totalList();

		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {

				try {

					selectOrder = tableView.getSelectionModel().getSelectedItems();
					order_Code = selectOrder.get(0).getOrder_Code();

					btn_Order_AddView.setDisable(true);
					btn_Order_Edit.setDisable(false);
					btn_Order_Delete.setDisable(false);
					btn_Order_Add_In.setDisable(false);
					btn_Order_Add_Delete.setDisable(false);

				} catch (Exception e) {

				}
			}

		});

	}

	// �ֹ� ���â Ȱ��ȭ
	public void handlerBtn_Order_AddViewAction(ActionEvent event) {

		try {
			Adddata.removeAll(Adddata);
			AddList();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/order_Add.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btn_Order_AddView.getScene().getWindow());
			dialog.setTitle("���");
			Parent parentAdd = (Parent) loader.load();

			Button btn_Order_Add_Ok = (Button) parentAdd.lookup("#btn_Order_Add_Ok");
			Button btn_Order_Add_Cancel = (Button) parentAdd.lookup("#btn_Order_Add_Cancel");
			Button btn_Order_Add_Search = (Button) parentAdd.lookup("#btn_Order_Add_Search");
			Button btn_Order_Add_Reset = (Button) parentAdd.lookup("#btn_Order_Add_Reset");

			TextField AddOrder_Date = (TextField) parentAdd.lookup("#txt_Order_Date");
			TextField AddOrder_Code = (TextField) parentAdd.lookup("#txt_Order_Code");
			TextField AddOrder_GoodsCode = (TextField) parentAdd.lookup("#txt_Order_GoodsCode");
			TextField AddOrder_GoodsName = (TextField) parentAdd.lookup("#txt_Order_GoodsName");
			TextField AddOrder_GoodsQuantity = (TextField) parentAdd.lookup("#txt_Order_GoodsQuantity");
			TextField AddOrder_GoodsPrice = (TextField) parentAdd.lookup("#txt_Order_GoodsPrice");
			TextArea AddOrder_GoodsRemarks = (TextArea) parentAdd.lookup("#txt_Order_GoodsRemarks");
			TextField txt_Order_Add_Search = (TextField) parentAdd.lookup("#txt_Order_Add_Search");

			// TextField txt_GoodsQuantity = (TextField)
			// parentAdd.lookup("#txt_GoodsQuantity");

			AddOrder_GoodsCode.setDisable(true);
			AddOrder_GoodsName.setDisable(true);
			AddOrder_GoodsPrice.setDisable(true);

			// ��� â �� ����ϴ� �� ��޾ȿ��� ���� �ؾ� ��� ����
			TableView<ItemStockVO> tableView_Order_Add_Search = (TableView<ItemStockVO>) parentAdd
					.lookup("#tableView_Order_Add_Search");

			tableView_Order_Add_Search.setOnMousePressed(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent event) {
					try {
						AddOrder = tableView_Order_Add_Search.getSelectionModel().getSelectedItems();
						selectedIndex = tableView_Order_Add_Search.getSelectionModel().getSelectedIndex();
						st_goodsCode = AddOrder.get(0).getGoodsCode();

						AddOrder_GoodsCode.setText(AddOrder.get(0).getGoodsCode() + "");
						AddOrder_GoodsName.setText(AddOrder.get(0).getGoodsName());
						AddOrder_GoodsQuantity.setText(AddOrder.get(0).getGoodsQuantity() + "");
						AddOrder_GoodsPrice.setText(AddOrder.get(0).getGoodsPrice() + "");

					} catch (Exception e) {
					}

				}
			});

			// order_Add_Search ���̺� �� �÷��̸� ����
			TableColumn colGoodsCode = new TableColumn("��ǰ �ڵ�");
			colGoodsCode.setMaxWidth(80);
			colGoodsCode.setStyle("-fx-allignment: CENTER");
			colGoodsCode.setCellValueFactory(new PropertyValueFactory<>("goodsCode"));

			TableColumn colGoodsName = new TableColumn("��ǰ ��");
			colGoodsName.setMaxWidth(80);
			colGoodsName.setStyle("-fx-allignment: CENTER");
			colGoodsName.setCellValueFactory(new PropertyValueFactory<>("goodsName"));

			TableColumn colGoodsQuantity = new TableColumn("����");
			colGoodsQuantity.setMaxWidth(80);
			colGoodsQuantity.setStyle("-fx-allignment: CENTER");
			colGoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("goodsQuantity"));

			TableColumn colGoodsPrice = new TableColumn("��ǰ�ܰ�");
			colGoodsPrice.setMaxWidth(80);
			colGoodsPrice.setStyle("-fx-allignment: CENTER");
			colGoodsPrice.setCellValueFactory(new PropertyValueFactory<>("goodsPrice"));

			tableView_Order_Add_Search.setItems(Adddata);
			tableView_Order_Add_Search.getColumns().addAll(colGoodsCode, colGoodsName, colGoodsQuantity, colGoodsPrice);

			// �ֹ� ��Ͻ� ��ǰ ���� ã��
			btn_Order_Add_Search.setOnAction(e -> {

				ItemStockVO iVo = new ItemStockVO();
				ItemStockDAO iDao = null;
				Object[][] totalData = null;

				String searchName = "";
				boolean searchResult = false;

				try {
					searchName = txt_Order_Add_Search.getText().trim();
					iDao = new ItemStockDAO();
					iVo = iDao.getItemStockCheck(searchName);

					if (searchName.equals("")) {
						searchResult = true;
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("��ǰ ���� �˻�");
						alert.setHeaderText("��ǰ�ڵ��� �Է��Ͻÿ�.");
						alert.setContentText("�������� �����ϼ���!");
						alert.showAndWait();
					}

					if (!searchName.equals("") && (iVo != null)) {
						Adddata.removeAll(Adddata);
						Adddata.add(iVo);
						searchResult = true;
					}

					if (!searchResult) {
						txt_Order_Add_Search.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("��ǰ ���� �˻�");
						alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();

					}

				} catch (Exception e1) {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("��ǰ ���� �˻�����");
					alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
					alert.setContentText("�ٽ� �ϼ���.");
					alert.showAndWait();
					e1.printStackTrace();

				}

			});

			// �ֹ����(���� �Է�)
			btn_Order_Add_Ok.setOnAction(e -> {

				// �ֹ� ��ü ����
				totalList();

				data.removeAll(data);
				OrderVO oVo = null;
				OrderDAO oDao = null;

				try {
					oVo = new OrderVO(AddOrder_Date.getText(), Integer.parseInt(AddOrder_Code.getText().trim()),
							Integer.parseInt(AddOrder_GoodsCode.getText().trim()), AddOrder_GoodsName.getText(),
							Integer.parseInt(AddOrder_GoodsQuantity.getText().trim()),
							Integer.parseInt(AddOrder_GoodsPrice.getText().trim()), AddOrder_GoodsRemarks.getText());

					oDao = new OrderDAO();
					oDao.getOrderregiste(oVo);

					Adddata.removeAll(Adddata);
					data.removeAll(data);
					totalList();
					AddList();

					data.removeAll(data);
					Adddata.removeAll(Adddata);

					if (oDao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("�ֹ� ���� �Է�");
						alert.setHeaderText(AddOrder_Code.getText() + " �ֹ��� ���������� �߰��Ǿ����ϴ�..");
						alert.setContentText("���� �ֹ��� �Է��ϼ���");
						alert.showAndWait();

						AddOrder_Date.clear();
						AddOrder_Code.clear();
						AddOrder_GoodsCode.clear();
						AddOrder_GoodsName.clear();
						AddOrder_GoodsQuantity.clear();
						AddOrder_GoodsPrice.clear();
						AddOrder_GoodsRemarks.clear();

						totalList();
						AddList();
					}

				} catch (Exception e1) {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ֹ� ���� �Է�");
					alert.setHeaderText("�ֹ� ������ ��Ȯ�� �Է��Ͻÿ�.");
					alert.setContentText("�������� �����ϼ���!");
					alert.showAndWait();
					e1.printStackTrace();
				}

			});

			// �ֹ��� ��ǰ �˻� ��ư �ʱ�ȭ
			btn_Order_Add_Reset.setOnAction(e -> {
				Adddata.removeAll(Adddata);
				AddList();
				AddOrder_Date.clear();
				AddOrder_Code.clear();
				AddOrder_GoodsCode.clear();
				AddOrder_GoodsName.clear();
				AddOrder_GoodsQuantity.clear();
				AddOrder_GoodsPrice.clear();
				AddOrder_GoodsRemarks.clear();
				txt_Order_Add_Search.clear();
			});

			// �ֹ���� �ݱ� (�ֹ�����â���� ���ư���)
			btn_Order_Add_Cancel.setOnAction(Event -> {
				dialog.close();

			});

			Scene scene = new Scene(parentAdd);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (IOException e) {
			System.out.println(e.toString());
		}

	}

	// �ֹ� ����â Ȱ��ȭ
	public void handlerBtn_Order_EditAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/order_Edit.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btn_Order_Edit.getScene().getWindow());
			dialog.setTitle("����");
			Parent parentEdit = (Parent) loader.load();

			OrderVO orderEdit = tableView.getSelectionModel().getSelectedItem();
			selectedIndex = tableView.getSelectionModel().getSelectedIndex();

			TextField EditOrder_Date = (TextField) parentEdit.lookup("#txt_Order_Date");
			TextField EditOrder_Code = (TextField) parentEdit.lookup("#txt_Order_Code");
			TextField EditOrder_GoodsCode = (TextField) parentEdit.lookup("#txt_Order_GoodsCode");
			TextField EditOrder_GoodsName = (TextField) parentEdit.lookup("#txt_Order_GoodsName");
			TextField EditOrder_GoodsQuantity = (TextField) parentEdit.lookup("#txt_Order_GoodsQuantity");
			TextField EditOrder_GoodsPrice = (TextField) parentEdit.lookup("#txt_Order_GoodsPrice");
			TextArea EditOrder_GoodsRemarks = (TextArea) parentEdit.lookup("#txt_Order_GoodsRemarks");

			EditOrder_Date.setDisable(true);
			EditOrder_Code.setDisable(true);
			EditOrder_GoodsCode.setDisable(true);
			EditOrder_GoodsName.setDisable(true);

			EditOrder_Date.setText(orderEdit.getOrder_Date());
			EditOrder_Code.setText(orderEdit.getOrder_Code() + "");
			EditOrder_GoodsCode.setText(orderEdit.getOrder_GoodsCode() + "");
			EditOrder_GoodsName.setText(orderEdit.getOrder_GoodsName());
			EditOrder_GoodsQuantity.setText(orderEdit.getOrder_GoodsQuantity() + "");
			EditOrder_GoodsPrice.setText(orderEdit.getOrder_GoodsPrice() + "");
			EditOrder_GoodsRemarks.setText(orderEdit.getOrder_GoodsRemarks());

			Button btn_Order_Edit_Ok = (Button) parentEdit.lookup("#btn_Order_Edit_Ok");
			Button btn_Order_Edit_Cancel = (Button) parentEdit.lookup("#btn_Order_Edit_Cancel");

			btn_Order_Edit_Cancel.setOnAction(e -> {
				dialog.close();
			});

			btn_Order_Edit_Ok.setOnAction(e -> {

				OrderVO oVo = null;
				OrderDAO oDao = null;

				TextField txt_Order_Date = (TextField) parentEdit.lookup("#txt_Order_Date");
				TextField txt_Order_Code = (TextField) parentEdit.lookup("#txt_Order_Code");
				TextField txt_Order_GoodsCode = (TextField) parentEdit.lookup("#txt_Order_GoodsCode");
				TextField txt_Order_GoodsName = (TextField) parentEdit.lookup("#txt_Order_GoodsName");
				TextField txt_Order_GoodsQuantity = (TextField) parentEdit.lookup("#txt_Order_GoodsQuantity");
				TextField txt_Order_GoodsPrice = (TextField) parentEdit.lookup("#txt_Order_GoodsPrice");
				TextArea txt_Order_GoodsRemarks = (TextArea) parentEdit.lookup("#txt_Order_GoodsRemarks");

				data.remove(selectedIndex);

				try {

					oVo = new OrderVO(txt_Order_Date.getText(), Integer.parseInt(txt_Order_Code.getText().trim()),
							Integer.parseInt(txt_Order_GoodsCode.getText().trim()), txt_Order_GoodsName.getText(),
							Integer.parseInt(txt_Order_GoodsQuantity.getText().trim()),
							Integer.parseInt(txt_Order_GoodsPrice.getText().trim()), txt_Order_GoodsRemarks.getText());

					oDao = new OrderDAO();
					oDao.getOrderUpdate(oVo, oVo.getOrder_Code());
					data.removeAll(data);
					totalList();
					dialog.close();

				} catch (Exception e1) {
					e1.printStackTrace();
				}

			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (IOException e) {
			System.out.println(e.toString());
		} catch (Exception e) {

		}

	}

	// �԰� ��ư
	public void handlerBtn_Order_Add_InAction(MouseEvent event) {
		try {
			OrderDAO iDao = null;
			iDao = new OrderDAO();
			if (event.getClickCount() != 2) {
				order_Code = tableView.getSelectionModel().getSelectedItem().getOrder_Code();
				st_goodsCode = tableView.getSelectionModel().getSelectedItem().getOrder_GoodsCode();

				try {

					iDao.orderItem_Add_ItemStock(order_Code, st_goodsCode);
					data.removeAll(data);
					totalList();

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��ǰ �԰�");
					alert.setHeaderText("��ǰ" + st_goodsCode + " �� ���������� �԰��Ǿ����ϴ�..");
					alert.setContentText("��� ����� Ȯ���ϼ���.");
					alert.showAndWait();

				} catch (Exception e1) {
					System.out.println("�԰� �̷� ��ư ���� ����" + e1);
				}

				// �԰��� ������ ���� �Ұ��� ���� ���� ���� �ؾ���
				// tableView.setDisable(g);
			}
		} catch (Exception e) {
		}

	}

	// �ֹ� ���(����)
	public void handlerBtn_Order_DeleteAction(ActionEvent event) {
		OrderDAO oDao = null;
		oDao = new OrderDAO();

		selectOrder = tableView.getSelectionModel().getSelectedItems();
		order_Code = selectOrder.get(0).getOrder_Code();

		try {

			oDao.getOrderDelete(order_Code);
			data.removeAll(data);
			totalList();

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("��ǰ �԰� ");
			alert.setHeaderText("��ǰ " + st_goodsCode + " �� ���������� �԰��Ǿ����ϴ�..");
			alert.setContentText("��� ����� Ȯ���ϼ���.");
			alert.showAndWait();

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	// �԰� ���
	public void handlerBtn_Order_Add_DeleteAction(MouseEvent event) {
		try {
			OrderDAO oDao = null;
			oDao = new OrderDAO();

			if (event.getClickCount() != 2) {
				order_Code = tableView.getSelectionModel().getSelectedItem().getOrder_Code();
				st_goodsCode = tableView.getSelectionModel().getSelectedItem().getOrder_GoodsCode();
				try {

					oDao.orderItem_Delete_ItemStock(order_Code, st_goodsCode);
					data.removeAll(data);
					totalList();

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��ǰ �԰� ���");
					alert.setHeaderText("��ǰ " + st_goodsCode + " ��  �԰��� ��� �Ǿ����ϴ�..");
					alert.setContentText("��� ����� Ȯ���ϼ���.");
					alert.showAndWait();

				} catch (Exception e) {
					e.printStackTrace();

				}
			}
		} catch (Exception e) {
		}
	}

	// �ֹ� �˻�
	public void handlerBtn_Order_SearchAction(ActionEvent event) {

		OrderVO oVo = new OrderVO();
		OrderDAO oDao = null;
		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txt_Order_Search.getText().trim();
			oDao = new OrderDAO();
			oVo = oDao.getOrderCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ �� �˻�");
				alert.setHeaderText("��ǰ ���� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (oVo != null)) {
				ArrayList<String> title;
				ArrayList<OrderVO> list;

				title = oDao.getColumnName();
				int columnCount = title.size();

				list = oDao.getOrderTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (oVo.getOrder_GoodsName().equals(searchName)) {
					txt_Order_Search.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						oVo = list.get(index);
						if (oVo.getOrder_GoodsName().equals(searchName)) {
							data.add(oVo);
							searchResult = true;

						}

					}
				}
			}
			if (!searchResult) {
				txt_Order_Search.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ �� �˻�");
				alert.setHeaderText(searchName + " �ֹ� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();

			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ �� �˻� ����");
			alert.setHeaderText("��ǰ �� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();

		}

	}

	// ���� (���� �޴��� ���ư���)
	public void handlerBtn_Order_ExitAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btn_Order_Exit.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}

	}

	public void handlerBtn_Order_TotalListAction(ActionEvent event) {
		data.removeAll(data);
		totalList();
	}

	// �ֹ� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		OrderDAO oDao = new OrderDAO();
		OrderVO oVo = null;
		ArrayList<String> title;
		ArrayList<OrderVO> list;

		title = oDao.getColumnName();
		int columnCount = title.size();

		list = oDao.getOrderTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			oVo = list.get(index);
			data.add(oVo);

			btn_Order_AddView.setDisable(false);
			btn_Order_Edit.setDisable(true);
			btn_Order_Delete.setDisable(true);
			btn_Order_Add_In.setDisable(true);
			btn_Order_Add_Delete.setDisable(true);
			txt_Order_Search.clear();

		}

	}

	// ��ǰ���� ��ü ����Ʈ
	public void AddList() {
		Object[][] totalData;

		ItemStockDAO iDao = new ItemStockDAO();
		ItemStockVO iVo = null;
		ArrayList<String> title;
		ArrayList<ItemStockVO> list;

		title = iDao.getColumnName();
		int columnCount = title.size();

		list = iDao.getItemStockTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			Adddata.add(iVo);
		}

	}

}

// �ڵ������ �����ϳ� ��޿� ����� �ȵ� (�ؽ�Ʈ �ʵ�� ��� �ҷ�����)
/*
 * AddOrder_GoodsCode.setOnMouseClicked(new EventHandler<MouseEvent>() {
 * 
 * @Override public void handle(MouseEvent event) { FXMLLoader loader = new
 * FXMLLoader();
 * loader.setLocation(getClass().getResource("/View/order_Add_Search.fxml"));
 * Stage dialog = new Stage(StageStyle.UTILITY);
 * dialog.initModality(Modality.WINDOW_MODAL);
 * dialog.initOwner(AddOrder_GoodsCode.getScene().getWindow());
 * dialog.setTitle("���");} })
 */
// �˻� ���� ����ȭ
/*
 * ItemStockVO iVo = new ItemStockVO(); ItemStockDAO iDao = null; Object[][]
 * totalData = null;
 * 
 * String searchName = ""; boolean searchResult = false;
 * 
 * try { searchName = txt_Order_Add_Search.getText().trim(); iDao = new
 * ItemStockDAO(); iVo = iDao.getItemStockCheck(searchName);
 * 
 * if (searchName.equals("")) { searchResult = true; Alert alert = new
 * Alert(AlertType.WARNING); alert.setTitle("��ǰ ���� �˻�");
 * alert.setHeaderText("��ǰ�ڵ��� �Է��Ͻÿ�."); alert.setContentText("�������� �����ϼ���!");
 * alert.showAndWait(); }
 * 
 * if (!searchName.equals("") && (iVo != null)) { Adddata.removeAll(Adddata);
 * Adddata.add(iVo); searchResult = true; }
 * 
 * if (!searchResult) { txt_Order_Add_Search.clear(); Alert alert = new
 * Alert(AlertType.INFORMATION); alert.setTitle("��ǰ ���� �˻�");
 * alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
 * alert.setContentText("�ٽ� �˻��ϼ���."); alert.showAndWait();
 * 
 * }
 * 
 * } catch (Exception e1) { Alert alert = new Alert(AlertType.ERROR);
 * alert.setTitle("��ǰ ���� �˻�����"); alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
 * alert.setContentText("�ٽ� �ϼ���."); alert.showAndWait(); e1.printStackTrace();
 * 
 * }
 * 
 * });
 * 
 */
