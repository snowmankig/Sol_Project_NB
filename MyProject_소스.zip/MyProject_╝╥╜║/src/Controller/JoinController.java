package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class JoinController implements Initializable {
	// �α׸�
	@FXML
	private AnchorPane login;

	// �ؽ�Ʈ �ʵ� ����
	@FXML
	private TextField txtFranchisee;
	@FXML
	private TextField txtAdminID;
	@FXML
	private TextField txtAdminPW;
	@FXML
	private TextField txtAdminPWT;
	@FXML
	private TextField txtAdminName;
	@FXML
	private TextField txtAdminTel;
	@FXML
	private TextField txtAdminPhone;

	// ��ư ����
	@FXML
	private Button btnAdminJoin;
	@FXML
	private Button btnAdminCancel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// ȸ�� ����â ��ư Ŭ�� �׼� ���ٽ�
		btnAdminCancel.setOnAction(event -> handlerBtnAdminCancelAction(event));
		btnAdminJoin.setOnAction(event -> handlerBtnAdminJoinAction(event));

	}

	// ��� ��ư �׼� ( �α���â���� �̵� )
	public void handlerBtnAdminCancelAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/login.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnAdminCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}
	}

	// ȸ������ �׼�
	public void handlerBtnAdminJoinAction(ActionEvent event) {
		
		// ��޷� ���� ���� ���ο� â���� ����� ���� �ؾ��� - 11.6

	}

}
