package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ItemStockVO;
import Model.StockEdit_List_AddVO;
import Model.StockEdit_List_DelVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ItemStockDAO {

	// ������ ���� �ؾ��� ���� �����

	// �⺻ �����
	public ItemStockVO getItemStockregiste(ItemStockVO iVo) throws Exception {
		String dml = "insert into ItemStock"
				+ "(st_goodsCode, st_goodsName, st_mainCategory, st_subCategory, st_goodsColor,"
				+ " st_goodsSize, st_goodsQuantity, st_goodsPrice, st_goodsSalesPrice, st_goodsRemarks, st_filename) "
				+ "values" + "( ?,?,?,?,?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		ItemStockVO retval = null;
		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, iVo.getGoodsCode());
			pstmt.setString(2, iVo.getGoodsName());
			pstmt.setString(3, iVo.getMainCategory());
			pstmt.setString(4, iVo.getSubCategory());
			pstmt.setInt(5, iVo.getGoodsColor());
			pstmt.setInt(6, iVo.getGoodsSize());
			pstmt.setInt(7, iVo.getGoodsQuantity());
			pstmt.setInt(8, iVo.getGoodsPrice());
			pstmt.setInt(9, iVo.getGoodsSalesPrice());
			pstmt.setString(10, iVo.getGoodsRemarks());
			pstmt.setString(11, iVo.getFilename());

			int i = pstmt.executeUpdate();

			retval = new ItemStockVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}
		}

		return retval;
	}

	// ��ǰ���� ��ü ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<ItemStockVO> getItemStockTotal() {
		ArrayList<ItemStockVO> ItemStock_list = new ArrayList<ItemStockVO>();
		String tml = "select * from itemStock";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ItemStockVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new ItemStockVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	// �����ͺ��̽����� ��ǰ���� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from ItemStock";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ������ ��ǰ������ ����
	public ItemStockVO getItemStockUpdate(ItemStockVO iVo, String goodsCode) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update ItemStock set"
				+ " st_goodsName=?, st_mainCategory=?, st_subCategory=?, st_goodsColor=?, st_goodsSize=?, st_goodsPrice=?, st_goodsSalesPrice=?, st_goodsRemarks=?, st_filename=? where st_goodsCode=?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ItemStockVO retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);

			pstmt.setString(1, iVo.getGoodsName());
			pstmt.setString(2, iVo.getMainCategory());
			pstmt.setString(3, iVo.getSubCategory());
			pstmt.setInt(4, iVo.getGoodsColor());
			pstmt.setInt(5, iVo.getGoodsSize());
			pstmt.setInt(6, iVo.getGoodsPrice());
			pstmt.setInt(7, iVo.getGoodsSalesPrice());
			pstmt.setString(8, iVo.getGoodsRemarks());
			pstmt.setString(9, iVo.getFilename());
			pstmt.setInt(10, iVo.getGoodsCode());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� �Ϸ�.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
				retval = new ItemStockVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� ����.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}
		}
		return retval;
	}

	public void getItemStockListUpdate(int StockEdit_Edit_Code, int st_goodsCode) {

		StringBuffer sql = new StringBuffer();

		// ��� ���̺� ����� ����� �Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity + StockEdit_GoodsQuantity ");

		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, stockEdit_List ");

		// ��ǰ �ڵ�(���) ��ǰ �ڵ�(�Ǹ�) �ֹ���ȣ
		sql.append(" where st_goodsCode = StockEdit_GoodsCode and StockEdit_Edit_Code =?)");

		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode = ? ");

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			pstmt.setInt(1, StockEdit_Edit_Code);
			pstmt.setInt(2, st_goodsCode);

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}

	public void getItemStockList_DelUpdate(int StockEdit_Edit_Code, int st_goodsCode) {

		StringBuffer sql = new StringBuffer();

		// ��� ���̺� ����� ����� �Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity - StockEdit_GoodsQuantity ");

		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, stockEdit_List ");

		// ��ǰ �ڵ�(���) ��ǰ �ڵ�(�Ǹ�) �ֹ���ȣ
		sql.append(" where st_goodsCode = StockEdit_GoodsCode and StockEdit_Edit_Code =?)");

		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode = ? ");

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			pstmt.setInt(1, StockEdit_Edit_Code);
			pstmt.setInt(2, st_goodsCode);

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}

	// �˻� ��
	public ItemStockVO getItemStockCheck(String goodsName) throws Exception {
		String dml = " select * from ItemStock where st_goodsName = ? ";
		Connection con = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		ItemStockVO sVo = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, goodsName);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				sVo = new ItemStockVO();
				sVo.setGoodsCode(rs.getInt("st_goodsCode"));
				sVo.setGoodsName(rs.getString("st_goodsName"));
				sVo.setGoodsColor(rs.getInt("st_goodsColor"));
				sVo.setGoodsSize(rs.getInt("st_goodsSize"));
				sVo.setGoodsPrice(rs.getInt("st_goodsPrice"));
				sVo.setGoodsQuantity(rs.getInt("st_goodsQuantity"));
				sVo.setGoodsSalesPrice(rs.getInt("st_goodsSalesPrice"));
				sVo.setGoodsRemarks(rs.getString("st_goodsRemarks"));
				sVo.setFilename(rs.getString("st_filename"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();
			} catch (SQLException se) {
			}
		}
		return sVo;
	}

	// ���ǰ�� ����
	public void getItemStockDelete(int searchCode) throws Exception {
		String dml = "delete from itemStock where st_goodsCode= ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, searchCode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� �Ϸ�.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� ����.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}
	}
	
	// ��� ���� ��� ����Ʈ ����
	public void getEditListDelete(int stockEdit_Edit_Code) throws Exception {
		
		String dml = "delete from stockEdit_List where stockEdit_Edit_Code = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, stockEdit_Edit_Code);
			
			int i = pstmt.executeUpdate();

			if (i != 1) {			
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��� ���� ���");
				alert.setHeaderText("��� ���� ��� ����.");
				alert.setContentText("�ٽ� Ȯ���ϼ���.");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}
	
			
		
	}
		

	
	// ��� ���� �߰�
	public void getAdd_ItemStockList_List(StockEdit_List_AddVO seiVo) throws Exception {

		String dml = "insert into stockEdit_List_Add"
				+ "(StockEdit_Edit_Add_Code, StockEdit_Edit_Add_Date, StockEdit_Add_GoodsCode, StockEdit_Add_GoodsName,"
				+ " StockEdit_Add_GoodsQuantity, StockEdit_Add_Edit_Remarks) " + "values " + "( ?,?,?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;

		StockEdit_List_AddVO retval = null;
		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, seiVo.getStockEdit_Edit_Add_Code());
			pstmt.setString(2, seiVo.getStockEdit_Add_Edit_Date());
			pstmt.setInt(3, seiVo.getStockEdit_Add_GoodsCode());
			pstmt.setString(4, seiVo.getStockEdit_Add_GoodsName());
			pstmt.setInt(5, seiVo.getStockEdit_Add_GoodsQuantity());
			pstmt.setString(6, seiVo.getStockEdit_Edit_Add_Remarks());

			int i = pstmt.executeUpdate();

			retval = new StockEdit_List_AddVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}
		}

	}

	
	// ��� ���� ���� 
	public void getDel_ItemStockList_List(StockEdit_List_DelVO seiVo) throws Exception {

		String dml = "insert into stockEdit_List_Del"
				+ "(StockEdit_Edit_Del_Code, StockEdit_Edit_Del_Date, StockEdit_Del_GoodsCode, StockEdit_Del_GoodsName,"
				+ " StockEdit_Del_GoodsQuantity, StockEdit_Del_Edit_Remarks) " + "values " + "( ?,?,?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;

		StockEdit_List_AddVO retval = null;
		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, seiVo.getStockEdit_Edit_Del_Code());
			pstmt.setString(2, seiVo.getStockEdit_Edit_Del_Date());
			pstmt.setInt(3, seiVo.getStockEdit_Del_GoodsCode());
			pstmt.setString(4, seiVo.getStockEdit_Del_GoodsName());
			pstmt.setInt(5, seiVo.getStockEdit_Del_GoodsQuantity());
			pstmt.setString(6, seiVo.getStockEdit_Edit_Del_Remarks());

			int i = pstmt.executeUpdate();

			retval = new StockEdit_List_AddVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}
		}

	}

	// ��� ���� �߰� ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<StockEdit_List_AddVO> getAddItemStockTotal() {
		ArrayList<StockEdit_List_AddVO> ItemStock_list = new ArrayList<StockEdit_List_AddVO>();
		String tml = "select * from stockEdit_List_Add";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockEdit_List_AddVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new StockEdit_List_AddVO(rs.getInt(1), rs.getDate(2) + "", rs.getInt(3), rs.getString(4),
						rs.getInt(5), rs.getString(6));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	// ��� ���� ���� ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<StockEdit_List_DelVO> getDelItemStockTotal() {
		ArrayList<StockEdit_List_DelVO> ItemStock_list = new ArrayList<StockEdit_List_DelVO>();
		String tml = "select * from stockEdit_List_Del";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockEdit_List_DelVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new StockEdit_List_DelVO(rs.getInt(1), rs.getDate(2) + "", rs.getInt(3), rs.getString(4),
						rs.getInt(5), rs.getString(6));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	
	
	
	
	
	// �޺��ڽ� �˻�
	// �޺��ڽ����� ������ ���� ��ü ����Ʈ���� �˻��ؾ���.
	// �޺� �ڽ� ���� itemStock, st_MainCategory�� �Ƿ�, �Ź�, ACC�� �з� ���� �Ǿ�����.
	
	
	
	
	public ArrayList<ItemStockVO> getItemStockCombo(String maincategory) throws Exception {
		String dml = " select * from ItemStock where st_mainCategory = ? ";
		ArrayList<ItemStockVO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		ItemStockVO sVo = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, maincategory);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				sVo = new ItemStockVO();
				sVo.setGoodsCode(rs.getInt("st_goodsCode"));
				sVo.setGoodsName(rs.getString("st_goodsName"));
				sVo.setMainCategory(rs.getString("st_mainCategory"));
				sVo.setSubCategory(rs.getString("st_SubCategory"));
				sVo.setGoodsColor(rs.getInt("st_goodsColor"));
				sVo.setGoodsSize(rs.getInt("st_goodsSize"));
				sVo.setGoodsPrice(rs.getInt("st_goodsPrice"));
				sVo.setGoodsSalesPrice(rs.getInt("st_goodsSalesPrice"));
				sVo.setGoodsRemarks(rs.getString("st_goodsRemarks"));
				sVo.setFilename(rs.getString("st_filename"));
				
				list.add(sVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();
			} catch (SQLException se) {
			}
		}
		return list;
	}
	
	
	
	
	
	/*public ArrayList<ItemStockVO> getListCheck(String cb_Main, String row) throws Exception {
		ArrayList<ItemStockVO> list = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		switch (cb_Main) {
		case "�Ƿ�?":
			sql.append("SELECT * FROM itemStock WHERE st_MainCategory LIKE ? ORDER BY �Ƿ�? ");
			break;

		case "�Ź�?":
			sql.append("SELECT * FROM itemStock WHERE st_MainCategory LIKE ? ORDER BY �Ź�? ");
			break;

		case "ACC?":
			sql.append("SELECT * FROM itemStock WHERE st_MainCategory LIKE ? ORDER BY ACC? ");
			break;

			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ItemStockVO sVo = null;

			try {
				con = DBUtil.getConnection();
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setString(1, "%" + row + "%");
				rs = pstmt.executeQuery();

				while (rs.next()) {
					sVo = new ItemStockVO();
					
					// ��� ���� �ؾ� ���� �� ���� ���� ���� �϶�
					// sVo.setNum(rs.getSting("C_NUM"));
					// sVo.setName(rs.getString("C_NAME"));
					// sVo.setAddress(rs.getString("C_ADDRESS"));

					list.add(sVo);
				}
			} catch (SQLException e) {
				System.out.println("e=[" + e + "]");
			} catch (Exception e) {
				System.out.println("e=[" + e + "]");
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (SQLException e) {
				}
			}
			return list;
		}
	}*/
}
