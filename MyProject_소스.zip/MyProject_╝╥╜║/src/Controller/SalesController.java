package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.ItemStockVO;
import Model.OrderVO;
import Model.SalesVO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class SalesController implements Initializable {

	// ���̺��� ����
	@FXML
	private TableView<SalesVO> tableView = new TableView<>();

	// ��ư ����
	@FXML
	private Button btn_Sales_TotalList; // ��ü �ֹ� Ȯ�� �� �ʱ�ȭ
	@FXML
	private Button btn_Sales_AddView; // �Ǹŵ�� ��ư
	@FXML
	private Button btn_Sales_Add_In; // ��� �Ϸ� ��ư
	@FXML
	private Button btn_Sales_Add_Cancel; // ��� ��ҹ�ư
	@FXML
	private Button btn_Sales_Edit; // �Ǹ� ���� ���� ��ư
	@FXML
	private Button btn_Sales_Delete; // �Ǹ���� ��ư
	@FXML
	private Button btn_Sales_Exit; // ���� ��ư
	@FXML
	private Button btn_Sales_Search; // �˻�

	// �ؽ�Ʈ �ʵ� ����
	@FXML
	private TextField txt_Sales_Date;
	@FXML
	private TextField txt_Sales_Code;
	@FXML
	private TextField txt_Sales_GoodsCode;
	@FXML
	private TextField txt_Sales_GoodsName;
	@FXML
	private TextField txt_Sales_GoodsQuantity;
	@FXML
	private TextField txt_Sales_GoodsPrice;
	@FXML
	private TextArea txt_Sales_GoodsRemarks;
	@FXML
	private TextField txt_Sales_Search;

	SalesVO sales = new SalesVO();
	ObservableList<SalesVO> data = FXCollections.observableArrayList();
	ObservableList<SalesVO> selectSales = null; // ���̺����� ������ ���� ����

	ObservableList<ItemStockVO> Adddata = FXCollections.observableArrayList();
	ObservableList<ItemStockVO> AddSales = null; // ���̺����� ������ ���� ����

	int selectedIndex; // ���̺����� ������ �ֹ� ���� �ε��� ����
	int sales_Code; // �ֹ� ���̺����� ���� �� �˻��� ���� ������ �ֹ���ǰ�ڵ� ����
	int sales_GoodsCode; // �ֹ� ���̺����� ���� �� �˻��� ���� ������ �ֹ���ǰ�ڵ� ����
	int st_goodsCode;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// ��ư�� �׼� ���ٽ�Ÿ�� (������)
		btn_Sales_AddView.setOnAction(event -> handlerBtn_Sales_AddViewAction(event));
		btn_Sales_Edit.setOnAction(event -> handlerBtn_Sales_EditAction(event));
		btn_Sales_Delete.setOnAction(event -> handlerBtn_Sales_DeleteAction(event));
		btn_Sales_Exit.setOnAction(event -> handlerBtn_Sales_ExitAction(event));
		btn_Sales_TotalList.setOnAction(event -> handlerBtn_Sales_TotalListAction(event));
		btn_Sales_Search.setOnAction(event -> handlerBtn_Sales_SearchAction(event));

		btn_Sales_Add_In.setOnMouseClicked(event -> handlerBtn_Sales_Add_InAction(event));
		btn_Sales_Add_Cancel.setOnMouseClicked(event -> handlerbtn_Sales_Add_CancelAction(event));

		// sales main���̺� �� �÷��̸� ����
		TableColumn colSales_Date = new TableColumn("�Ǹ�����");
		colSales_Date.setMinWidth(200);
		colSales_Date.setStyle("-fx-allignment: CENTER");
		colSales_Date.setCellValueFactory(new PropertyValueFactory<>("sales_Date"));

		TableColumn colSales_Code = new TableColumn("�ǸŹ�ȣ");
		colSales_Code.setMinWidth(100);
		colSales_Code.setStyle("-fx-allignment: CENTER");
		colSales_Code.setCellValueFactory(new PropertyValueFactory<>("sales_Code"));

		TableColumn colSales_GoodsCode = new TableColumn("��ǰ�ڵ�");
		colSales_GoodsCode.setMinWidth(100);
		colSales_GoodsCode.setStyle("-fx-allignment: CENTER");
		colSales_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("sales_GoodsCode"));

		TableColumn colSales_GoodsName = new TableColumn("��ǰ��");
		colSales_GoodsName.setMinWidth(150);
		colSales_GoodsName.setStyle("-fx-allignment: CENTER");
		colSales_GoodsName.setCellValueFactory(new PropertyValueFactory<>("sales_GoodsName"));

		TableColumn colSales_GoodsQuantity = new TableColumn("��ǰ����");
		colSales_GoodsQuantity.setMaxWidth(80);
		colSales_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colSales_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("sales_GoodsQuantity"));

		TableColumn colSales_GoodsSalesPrice = new TableColumn("�ǸŴܰ�");
		colSales_GoodsSalesPrice.setMinWidth(100);
		colSales_GoodsSalesPrice.setStyle("-fx-allignment: CENTER");
		colSales_GoodsSalesPrice.setCellValueFactory(new PropertyValueFactory<>("sales_GoodsSalesPrice"));

		TableColumn colSales_GoodsRemarks = new TableColumn("���");
		colSales_GoodsRemarks.setMinWidth(200);
		colSales_GoodsRemarks.setStyle("-fx-allignment: CENTER");
		colSales_GoodsRemarks.setCellValueFactory(new PropertyValueFactory<>("sales_GoodsRemarks"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colSales_Date, colSales_Code, colSales_GoodsCode, colSales_GoodsName,
				colSales_GoodsQuantity, colSales_GoodsSalesPrice, colSales_GoodsRemarks);

		totalList();

		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {

				try {

					selectSales = tableView.getSelectionModel().getSelectedItems();
					sales_Code = selectSales.get(0).getSales_Code();

					btn_Sales_AddView.setDisable(true);
					btn_Sales_Edit.setDisable(false);
					btn_Sales_Delete.setDisable(false);
					btn_Sales_Add_In.setDisable(false);
					btn_Sales_Add_Cancel.setDisable(false);

				} catch (Exception e) {

				}
			}

		});

	}

	// �Ǹ� ���â Ȱ��ȭ
	public void handlerBtn_Sales_AddViewAction(ActionEvent event) {

		try {

			Adddata.removeAll(Adddata);
			AddList();
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/sales_Add.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btn_Sales_AddView.getScene().getWindow());
			dialog.setTitle("���");
			Parent parentAdd = (Parent) loader.load();

			Button btn_Sales_Add_Ok = (Button) parentAdd.lookup("#btn_Sales_Add_Ok");
			Button btn_Sales_Add_Cancel = (Button) parentAdd.lookup("#btn_Sales_Add_Cancel");
			Button btn_Sales_Add_Search = (Button) parentAdd.lookup("#btn_Sales_Add_Search");
			Button btn_Sales_Add_Reset = (Button) parentAdd.lookup("#btn_Sales_Add_Reset");

			TextField AddSales_Date = (TextField) parentAdd.lookup("#txt_Sales_Date");
			TextField AddSales_Code = (TextField) parentAdd.lookup("#txt_Sales_Code");
			TextField AddSales_GoodsCode = (TextField) parentAdd.lookup("#txt_Sales_GoodsCode");
			TextField AddSales_GoodsName = (TextField) parentAdd.lookup("#txt_Sales_GoodsName");
			TextField AddSales_GoodsQuantity = (TextField) parentAdd.lookup("#txt_Sales_GoodsQuantity");
			TextField AddSales_GoodsSalesPrice = (TextField) parentAdd.lookup("#txt_Sales_GoodsSalesPrice");
			TextArea AddSales_GoodsRemarks = (TextArea) parentAdd.lookup("#txt_Sales_GoodsRemarks");
			TextField txt_Sales_Add_Search = (TextField) parentAdd.lookup("#txt_Sales_Add_Search");

			AddSales_GoodsCode.setDisable(true);
			AddSales_GoodsName.setDisable(true);
			AddSales_GoodsSalesPrice.setDisable(true);

			// ��� â �� ����ϴ� �� ��޾ȿ��� ���� �ؾ� ��� ����
			TableView<ItemStockVO> tableView_Sales_Add_Search = (TableView<ItemStockVO>) parentAdd
					.lookup("#tableView_Sales_Add_Search");

			tableView_Sales_Add_Search.setOnMousePressed(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent event) {
					try {
						AddSales = tableView_Sales_Add_Search.getSelectionModel().getSelectedItems();
						selectedIndex = tableView_Sales_Add_Search.getSelectionModel().getSelectedIndex();
						st_goodsCode = AddSales.get(0).getGoodsCode();

						AddSales_GoodsCode.setText(AddSales.get(0).getGoodsCode() + "");
						AddSales_GoodsName.setText(AddSales.get(0).getGoodsName());
						AddSales_GoodsQuantity.setText(AddSales.get(0).getGoodsQuantity() + "");
						AddSales_GoodsSalesPrice.setText(AddSales.get(0).getGoodsSalesPrice() + "");

					} catch (Exception e) {
					}

				}
			});

			// Sales_Add_Search ���̺� �� �÷��̸� ����
			TableColumn colGoodsCode = new TableColumn("��ǰ �ڵ�");
			colGoodsCode.setMaxWidth(80);
			colGoodsCode.setStyle("-fx-allignment: CENTER");
			colGoodsCode.setCellValueFactory(new PropertyValueFactory<>("goodsCode"));

			TableColumn colGoodsName = new TableColumn("��ǰ ��");
			colGoodsName.setMaxWidth(80);
			colGoodsName.setStyle("-fx-allignment: CENTER");
			colGoodsName.setCellValueFactory(new PropertyValueFactory<>("goodsName"));

			TableColumn colGoodsQuantity = new TableColumn("����");
			colGoodsQuantity.setMaxWidth(80);
			colGoodsQuantity.setStyle("-fx-allignment: CENTER");
			colGoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("goodsQuantity"));

			TableColumn colGoodsSalesPrice = new TableColumn("�ǸŴܰ�");
			colGoodsSalesPrice.setMaxWidth(80);
			colGoodsSalesPrice.setStyle("-fx-allignment: CENTER");
			colGoodsSalesPrice.setCellValueFactory(new PropertyValueFactory<>("goodsSalesPrice"));

			tableView_Sales_Add_Search.setItems(Adddata);
			tableView_Sales_Add_Search.getColumns().addAll(colGoodsCode, colGoodsName, colGoodsQuantity,
					colGoodsSalesPrice);

			// �Ǹ� ��Ͻ� ��ǰ ���� ã��
			btn_Sales_Add_Search.setOnAction(e -> {

				ItemStockVO iVo = new ItemStockVO();
				ItemStockDAO iDao = null;
				Object[][] totalData = null;

				String searchName = "";
				boolean searchResult = false;

				try {
					searchName = txt_Sales_Add_Search.getText().trim();
					iDao = new ItemStockDAO();
					iVo = iDao.getItemStockCheck(searchName);

					if (searchName.equals("")) {
						searchResult = true;
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("��ǰ ���� �˻�");
						alert.setHeaderText("��ǰ�ڵ��� �Է��Ͻÿ�.");
						alert.setContentText("�������� �����ϼ���!");
						alert.showAndWait();
					}

					if (!searchName.equals("") && (iVo != null)) {
						Adddata.removeAll(Adddata);
						Adddata.add(iVo);
						searchResult = true;
					}

					if (!searchResult) {
						txt_Sales_Add_Search.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("��ǰ ���� �˻�");
						alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();

					}

				} catch (Exception e1) {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("��ǰ ���� �˻�����");
					alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
					alert.setContentText("�ٽ� �ϼ���.");
					alert.showAndWait();
					e1.printStackTrace();

				}

			});

			// �ֹ����(���� �Է�)
			btn_Sales_Add_Ok.setOnAction(e -> {

				// �ֹ� ��ü ����
				totalList();

				data.removeAll(data);
				SalesVO oVo = null;
				SalesDAO oDao = null;

				try {
					oVo = new SalesVO(AddSales_Date.getText(), Integer.parseInt(AddSales_Code.getText().trim()),
							Integer.parseInt(AddSales_GoodsCode.getText().trim()), AddSales_GoodsName.getText(),
							Integer.parseInt(AddSales_GoodsQuantity.getText().trim()),
							Integer.parseInt(AddSales_GoodsSalesPrice.getText().trim()),
							AddSales_GoodsRemarks.getText());

					oDao = new SalesDAO();
					oDao.getSalesregiste(oVo);

					Adddata.removeAll(Adddata);
					data.removeAll(data);
					totalList();
					AddList();

					data.removeAll(data);
					Adddata.removeAll(Adddata);

					if (oDao != null) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("�Ǹ� ���� �Է�");
						alert.setHeaderText(AddSales_Code.getText() + " �ǸŰ� ���������� �߰��Ǿ����ϴ�..");
						alert.setContentText("�Ǹ� �ֹ��� �Է��ϼ���");
						alert.showAndWait();

						AddSales_Date.clear();
						AddSales_Code.clear();
						AddSales_GoodsCode.clear();
						AddSales_GoodsName.clear();
						AddSales_GoodsQuantity.clear();
						AddSales_GoodsSalesPrice.clear();
						AddSales_GoodsRemarks.clear();

						totalList();
						AddList();
					}

				} catch (Exception e1) {

					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�Ǹ� ���� �Է�");
					alert.setHeaderText("�Ǹ� ������ ��Ȯ�� �Է��Ͻÿ�.");
					alert.setContentText("�������� �����ϼ���!");
					alert.showAndWait();
					e1.printStackTrace();
				}

			});

			// �Ǹſ� ��ǰ �˻� ��ư �ʱ�ȭ
			btn_Sales_Add_Reset.setOnAction(e -> {
				Adddata.removeAll(Adddata);
				AddList();
				AddSales_Date.clear();
				AddSales_Code.clear();
				AddSales_GoodsCode.clear();
				AddSales_GoodsName.clear();
				AddSales_GoodsQuantity.clear();
				AddSales_GoodsSalesPrice.clear();
				AddSales_GoodsRemarks.clear();
				txt_Sales_Add_Search.clear();

			});

			// �ֹ���� ��� (�ֹ�����â���� ���ư���)
			btn_Sales_Add_Cancel.setOnAction(Event -> {
				dialog.close();

			});

			Scene scene = new Scene(parentAdd);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	// �Ǹ� ����â Ȱ��ȭ
	public void handlerBtn_Sales_EditAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/sales_Edit.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btn_Sales_Edit.getScene().getWindow());
			dialog.setTitle("����");
			Parent parentEdit = (Parent) loader.load();

			SalesVO salesEdit = tableView.getSelectionModel().getSelectedItem();
			selectedIndex = tableView.getSelectionModel().getSelectedIndex();

			TextField EditSales_Date = (TextField) parentEdit.lookup("#txt_Sales_Edit_Date");
			TextField EditSales_Code = (TextField) parentEdit.lookup("#txt_Sales_Edit_Code");
			TextField EditSales_GoodsCode = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsCode");
			TextField EditSales_GoodsName = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsName");
			TextField EditSales_GoodsQuantity = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsQuantity");
			TextField EditSales_GoodsSalesPrice = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsSalesPrice");
			TextArea EditSales_GoodsRemarks = (TextArea) parentEdit.lookup("#txt_Sales_Edit_GoodsRemarks");

			EditSales_Date.setDisable(true);
			EditSales_Code.setDisable(true);
			EditSales_GoodsCode.setDisable(true);
			EditSales_GoodsName.setDisable(true);

			EditSales_Date.setText(salesEdit.getSales_Date());
			EditSales_Code.setText(salesEdit.getSales_Code() + "");
			EditSales_GoodsCode.setText(salesEdit.getSales_GoodsCode() + "");
			EditSales_GoodsName.setText(salesEdit.getSales_GoodsName());
			EditSales_GoodsQuantity.setText(salesEdit.getSales_GoodsQuantity() + "");
			EditSales_GoodsSalesPrice.setText(salesEdit.getSales_GoodsSalesPrice() + "");
			EditSales_GoodsRemarks.setText(salesEdit.getSales_GoodsRemarks());

			Button btn_Sales_Edit_Ok = (Button) parentEdit.lookup("#btn_Sales_Edit_Ok");
			Button btn_Sales_Edit_Cancel = (Button) parentEdit.lookup("#btn_Sales_Edit_Cancel");

			btn_Sales_Edit_Cancel.setOnAction(e -> {
				dialog.close();
			});

			btn_Sales_Edit_Ok.setOnAction(e -> {

				SalesVO oVo = null;
				SalesDAO oDao = null;

				TextField txt_Sales_Date = (TextField) parentEdit.lookup("#txt_Sales_Edit_Date");
				TextField txt_Sales_Code = (TextField) parentEdit.lookup("#txt_Sales_Edit_Code");
				TextField txt_Sales_GoodsCode = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsCode");
				TextField txt_Sales_GoodsName = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsName");
				TextField txt_Sales_GoodsQuantity = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsQuantity");
				TextField txt_Sales_GoodsSalesPrice = (TextField) parentEdit.lookup("#txt_Sales_Edit_GoodsSalesPrice");
				TextArea txt_Sales_GoodsRemarks = (TextArea) parentEdit.lookup("#txt_Sales_Edit_GoodsRemarks");

				data.remove(selectedIndex);

				try {

					oVo = new SalesVO(txt_Sales_Date.getText(), Integer.parseInt(txt_Sales_Code.getText().trim()),
							Integer.parseInt(txt_Sales_GoodsCode.getText().trim()), txt_Sales_GoodsName.getText(),
							Integer.parseInt(txt_Sales_GoodsQuantity.getText().trim()),
							Integer.parseInt(txt_Sales_GoodsSalesPrice.getText().trim()),
							txt_Sales_GoodsRemarks.getText());

					oDao = new SalesDAO();
					oDao.getOrderUpdate(oVo, oVo.getSales_Code());
					data.removeAll(data);
					totalList();
					dialog.close();

				} catch (Exception e1) {
					e1.printStackTrace();
				}

			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (IOException e) {
			System.out.println(e.toString());
		} catch (Exception e) {

		}

	}

	// �Ǹ� ��� Ȱ��ȭ
	public void handlerBtn_Sales_DeleteAction(ActionEvent event) {

		SalesDAO oDao = null;
		oDao = new SalesDAO();

		selectSales = tableView.getSelectionModel().getSelectedItems();
		sales_Code = selectSales.get(0).getSales_Code();

		try {

			oDao.getSalesDelete(sales_Code);
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	// �Ǹ�â ����
	public void handlerBtn_Sales_ExitAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btn_Sales_Exit.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}

	}

	// ��ü �Ǹ� ����Ʈ Ȱ��ȭ
	public void handlerBtn_Sales_TotalListAction(ActionEvent event) {

		data.removeAll(data);
		totalList();

	}

	// �Ǹ� �˻�
	public void handlerBtn_Sales_SearchAction(ActionEvent event) {

		SalesVO sVo = new SalesVO();
		SalesDAO sDao = null;
		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txt_Sales_Search.getText().trim();
			sDao = new SalesDAO();
			sVo = sDao.getSalesCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ �� �˻�");
				alert.setHeaderText("��ǰ ���� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (sVo != null)) {
				ArrayList<String> title;
				ArrayList<SalesVO> list;

				title = sDao.getColumnName();
				int columnCount = title.size();

				list = sDao.getSalesTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (sVo.getSales_GoodsName().equals(searchName)) {
					txt_Sales_Search.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						sVo = list.get(index);
						if (sVo.getSales_GoodsName().equals(searchName)) {
							data.add(sVo);
							searchResult = true;

						}

					}
				}
			}
			if (!searchResult) {
				txt_Sales_Search.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ �� �˻�");
				alert.setHeaderText(searchName + " �ֹ� ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();

			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ �� �˻� ����");
			alert.setHeaderText("��ǰ �� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();

		}

	}

	// ��� Ȱ��ȭ
	public void handlerBtn_Sales_Add_InAction(MouseEvent event) {
		SalesDAO sDao = null;
		sDao = new SalesDAO();
		if (event.getClickCount() != 2) {
			sales_Code = tableView.getSelectionModel().getSelectedItem().getSales_Code();
			st_goodsCode = tableView.getSelectionModel().getSelectedItem().getSales_GoodsCode();
			try {

				sDao.salesItem_Add_ItemStock(sales_Code, st_goodsCode);
				data.removeAll(data);
				totalList();

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ �Ǹ�");
				alert.setHeaderText("��ǰ" + st_goodsCode + " ��  �Ǹ� �Ǿ����ϴ�..");
				alert.setContentText("��� ����� Ȯ���ϼ���.");
				alert.showAndWait();

			} catch (Exception e1) {
				System.out.println("�԰� �̷� ��ư ���� ����" + e1);
			}
		}
	}

	// ��� ��� Ȱ��ȭ
	public void handlerbtn_Sales_Add_CancelAction(MouseEvent event) {

		try {
			SalesDAO sDao = null;
			sDao = new SalesDAO();
			if (event.getClickCount() != 2) {
				sales_Code = tableView.getSelectionModel().getSelectedItem().getSales_Code();
				st_goodsCode = tableView.getSelectionModel().getSelectedItem().getSales_GoodsCode();

				try {

					sDao.salesItem_Delete_ItemStock(sales_Code, st_goodsCode);
					data.removeAll(data);
					totalList();

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��ǰ ��� ���");
					alert.setHeaderText("��ǰ " + st_goodsCode + " ��  ����� ��� �Ǿ����ϴ�..");
					alert.setContentText("��� ����� Ȯ���ϼ���.");
					alert.showAndWait();

				} catch (Exception e1) {
					System.out.println("�԰� �̷� ��ư ���� ����" + e1);
				}
			}
		} catch (Exception e) {
		}

	}

	// �ֹ� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		SalesDAO oDao = new SalesDAO();
		SalesVO oVo = null;
		ArrayList<String> title;
		ArrayList<SalesVO> list;

		title = oDao.getColumnName();
		int columnCount = title.size();

		list = oDao.getSalesTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			oVo = list.get(index);
			data.add(oVo);

			btn_Sales_AddView.setDisable(false);
			btn_Sales_Edit.setDisable(true);
			btn_Sales_Delete.setDisable(true);
			btn_Sales_Add_In.setDisable(true);
			btn_Sales_Add_Cancel.setDisable(true);
		}

	}

	// ��ǰ���� ��ü ����Ʈ
	public void AddList() {
		Object[][] totalData;

		ItemStockDAO iDao = new ItemStockDAO();
		ItemStockVO iVo = null;
		ArrayList<String> title;
		ArrayList<ItemStockVO> list;

		title = iDao.getColumnName();
		int columnCount = title.size();

		list = iDao.getItemStockTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			Adddata.add(iVo);
		}

	}

}
