package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.StockEdit_ListVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class StockEdit_ListDAO {

	// ����Ʈ ���� �����
	public StockEdit_ListVO getStockEditregiste(StockEdit_ListVO seVo) throws Exception {

		String dml = "insert into stockEdit_List"
				+ "(StockEdit_Edit_Code, StockEdit_Edit_Date, StockEdit_GoodsCode, StockEdit_GoodsName, StockEdit_GoodsQuantity, StockEdit_Edit_Remarks)"
				+ "values" + "( ?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		StockEdit_ListVO retval = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, seVo.getStockEdit_Edit_Code());
			pstmt.setString(2, seVo.getStockEdit_Edit_Date());
			pstmt.setInt(3, seVo.getStockEdit_GoodsCode());
			pstmt.setString(4, seVo.getStockEdit_GoodsName());
			pstmt.setInt(5, seVo.getStockEdit_GoodsQuantity());
			pstmt.setString(6, seVo.getStockEdit_Edit_Remarks());
			int i = pstmt.executeUpdate();

			retval = new StockEdit_ListVO();

		} catch (SQLException e) {

			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}

		}
		return retval;
	}

	// ����Ʈ ���� ��Ż����Ʈ
	public ArrayList<StockEdit_ListVO> getStockEditTotal() {
		ArrayList<StockEdit_ListVO> list = new ArrayList<StockEdit_ListVO>();
		String tml = "select * from stockEdit_List";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockEdit_ListVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new StockEdit_ListVO(
						rs.getInt(1), rs.getDate(2) + "", rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getString(6));
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return list;
	}

	/*
	 * 
	 * // ���� ���� ��ü ����Ʈ public ArrayList<StockEdit_ListVO> getItemStockTotal() {
	 * ArrayList<StockEdit_ListVO> StockEdit_list = new
	 * ArrayList<StockEdit_ListVO>(); String tml = "select * from stockEdit_List";
	 * 
	 * Connection con = null; PreparedStatement pstmt = null; ResultSet rs = null;
	 * StockEdit_ListVO emVo = null;
	 * 
	 * try { con = DBUtil.getConnection(); pstmt = con.prepareStatement(tml); rs =
	 * pstmt.executeQuery();
	 * 
	 * while (rs.next()) { emVo = new StockEdit_ListVO(rs.getString(1),
	 * rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5));
	 * StockEdit_list.add(emVo); } } catch (SQLException se) {
	 * System.out.println(se);
	 * 
	 * } catch (Exception e) { System.out.println(e); } finally { try { if (rs !=
	 * null) rs.close(); if (pstmt != null) pstmt.close(); if (con != null)
	 * con.close();
	 * 
	 * } catch (SQLException se) { } } return StockEdit_list; }
	 */
	// �����ͺ��̽����� �ֹ� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from stockEdit_List";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ����Ʈ ���� ���� ���� = �̱��� ��������
	public void getSalesDelete(int sales_Code) throws Exception {
		String dml = "delete from salesInfo where sales_Code = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, sales_Code);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ���");
				alert.setHeaderText("�Ǹ� ��� �Ϸ�.");
				alert.setContentText("�Ǹ� ��� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ���");
				alert.setHeaderText("�Ǹ� ��� ����.");
				alert.setContentText("�Ǹ� ��� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}

	}
}
