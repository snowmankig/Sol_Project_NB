package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.AdminVO;
import Model.OrderVO;
import Controller.DBUtil;

public class AdminDAO {

	// ȸ������ ����
	public AdminVO getAdminRegiste(AdminVO avo) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("insert into adminInfo");
		sql.append("(no, fc_Code, adminID, adminPW, adminPWT, adminName, adminTel, adminPhone)");
		sql.append("values ( adminInfo_seq.nextval,?,?,?,?,?,?,?)");

		Connection con = null;
		PreparedStatement pstmt = null;
		AdminVO aVo = avo;

		try {
			// DBUtil�̶�� Ŭ������ getConnection() �ż���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();
			// aVo=new AminVO();
			// 4 �Է¹��� ȸ������ ������ ó���ϱ� ���Ͽ� SQL������ ����

			pstmt = con.prepareStatement(sql.toString());

			pstmt.setString(1, aVo.getFc_Code());
			pstmt.setString(2, aVo.getAdminID());
			pstmt.setString(3, aVo.getAdminPW());
			pstmt.setString(4, aVo.getAdminPWT());
			pstmt.setString(5, aVo.getAdminName());
			pstmt.setString(6, aVo.getAdminTel());
			pstmt.setString(7, aVo.getAdminPhone());

			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}

		}
		return aVo;
	}

	// ȸ�� ���̵� �ߺ� �˻�

	public AdminVO getAdminIdSearch(String adminID) throws Exception {
		String dml = "select * from adminInfo where adminId = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdminVO aVo = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, adminID);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				aVo = new AdminVO();
				aVo.setAdminID(rs.getString("adminID"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();

			} catch (Exception e) {
			}

		}
		return aVo;
	}

	// �˻� �� �ߺ� Ȯ���� ���� �ҽ� �� �޼ҵ� �߰� �ؾ��� - 11.7
}
