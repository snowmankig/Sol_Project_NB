
package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ItemStockVO;
import Model.OrderVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import Controller.DBUtil;

public class OrderDAO {

	public OrderVO getOrderregiste(OrderVO oVo) throws Exception {
		String dml = "insert into orderInfo"
				+ "(order_Date, order_Code, order_GoodsCode, order_GoodsName, order_GoodsQuantity , order_GoodsPrice, order_GoodsRemarks)"
				+ "values" + "( ?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		OrderVO retval = null;

		try {
			// DBUtil�̶�� Ŭ������ getConnection() �ż���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, oVo.getOrder_Date());
			pstmt.setInt(2, oVo.getOrder_Code());
			pstmt.setInt(3, oVo.getOrder_GoodsCode());
			pstmt.setString(4, oVo.getOrder_GoodsName());
			pstmt.setInt(5, oVo.getOrder_GoodsQuantity());
			pstmt.setInt(6, oVo.getOrder_GoodsPrice());
			pstmt.setString(7, oVo.getOrder_GoodsRemarks());

			int i = pstmt.executeUpdate();

			retval = new OrderVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}

		}
		return retval;
	}

	// �ֹ� ��ü ����Ʈ Ȯ�ο�
	public ArrayList<OrderVO> getOrderTotal() {
		ArrayList<OrderVO> list = new ArrayList<OrderVO>();
		String tml = "select * from orderInfo";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		OrderVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new OrderVO(rs.getDate(1) + "", rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getString(7));
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return list;
	}

	// �����ͺ��̽����� �ֹ� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from orderInfo";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ������ �ֹ������� ����
	public OrderVO getOrderUpdate(OrderVO ovo, int order_Code) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update orderInfo set"
				+ " order_GoodsQuantity=?, order_GoodsPrice=?, order_GoodsRemarks=? where order_Code=?";
		Connection con = null;
		PreparedStatement pstmt = null;
		OrderVO retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, ovo.getOrder_GoodsQuantity());
			pstmt.setInt(2, ovo.getOrder_GoodsPrice());
			pstmt.setString(3, ovo.getOrder_GoodsRemarks());
			pstmt.setInt(4, order_Code);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ� ����");
				alert.setHeaderText("�ֹ� ���� �Ϸ�.");
				alert.setContentText("�ֹ� ���� ����!!!");
				alert.showAndWait();
				retval = new OrderVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ� ����");
				alert.setHeaderText("�ֹ� ���� ����.");
				alert.setContentText("�ֹ� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}
		}
		return retval;
	}

	// �ֹ� ����
	public void getOrderDelete(int order_Code) throws Exception {
		String dml = "delete from orderInfo where order_Code = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, order_Code);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ� ���");
				alert.setHeaderText("�ֹ� ��� �Ϸ�.");
				alert.setContentText("�ֹ� ��� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ� ���");
				alert.setHeaderText("�ֹ� ��� ����.");
				alert.setContentText("�ֹ� ��� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}

	}

	// �˻� �� 
	public OrderVO getOrderCheck(String order_GoodsName) throws Exception {
		String dml = "select * from orderInfo where order_GoodsName = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		OrderVO sVo = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, order_GoodsName);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				sVo = new OrderVO();
				sVo.setOrder_Date(rs.getString("order_Date"));
				sVo.setOrder_Code(rs.getInt("order_Code"));
				sVo.setOrder_GoodsCode(rs.getInt("order_GoodsCode"));
				sVo.setOrder_GoodsName(rs.getString("order_GoodsName"));
				sVo.setOrder_GoodsQuantity(rs.getInt("order_GoodsQuantity"));
				sVo.setOrder_GoodsPrice(rs.getInt("order_GoodsPrice"));
				sVo.setOrder_GoodsRemarks(rs.getString("order_GoodsRemarks"));
				
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();
			} catch (SQLException se) {
			}
		}
		return sVo;
	}

	// ��ǰ���� ��ü ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<ItemStockVO> getItemStockTotal() {
		ArrayList<ItemStockVO> ItemStock_list = new ArrayList<ItemStockVO>();
		String tml = "select * from itemStock";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ItemStockVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new ItemStockVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	public void orderItem_Add_ItemStock(int order_Code, int st_goodsCode) {
		StringBuffer sql = new StringBuffer();
		
		
		//��� ���̺�	      	�����					�����				�Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity + order_GoodsQuantity ");


		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, orderInfo ");

		// ��ǰ �ڵ�(���)		��ǰ �ڵ�(�Ǹ�)			�ֹ���ȣ
		sql.append(" where st_goodsCode = order_GoodsCode and order_Code =?)");


		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode =? ");

		Connection con = null;
		PreparedStatement pstmt = null;
	
		try {
			
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			
			pstmt.setInt(1, order_Code );
			pstmt.setInt(2, st_goodsCode );
			
		
		
			int i = pstmt.executeUpdate();
			
		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}
	
	public void orderItem_Delete_ItemStock(int order_Code, int st_goodsCode) {
		StringBuffer sql = new StringBuffer();
		
		
		//��� ���̺�	      	�����					�����				�Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity - order_GoodsQuantity ");


		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, orderInfo ");

		// ��ǰ �ڵ�(���)		��ǰ �ڵ�(�Ǹ�)			�ֹ���ȣ
		sql.append(" where st_goodsCode = order_GoodsCode and order_Code =?)");


		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode =? ");

		Connection con = null;
		PreparedStatement pstmt = null;
	
		try {
			
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			
			pstmt.setInt(1, order_Code );
			pstmt.setInt(2, st_goodsCode );
			
		
		
			int i = pstmt.executeUpdate();
			
		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}
}

//â��
/*//��� ���̺�		�����					�����				�Ǹŷ�
sql.append(" update itemStock set st_goodsQuantity = st_goodsQuantity + (select order_GoodsQuantity ");


		// ��� ���̺�,    �ֹ����̺�
sql.append(" from orderInfo, itemStock ");

		// ��ǰ ��ȣ(���)		��ǰ��ȣ(�Ǹ�)			�ֹ���ȣ
sql.append(" where st_goodsCode  = order_GoodsCode and order_Code = ? )");


		// ��ǰ ��ȣ
sql.append(" where st_goodsCode =? ");*/
//�̴�
/*//��� ���̺�	      	�����					�����				�Ǹŷ�
sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity + order_GoodsQuantity ");


// ��� ���̺�, �ֹ����̺�
sql.append(" from itemStock, orderInfo ");

// ��ǰ �ڵ�(���)		��ǰ �ڵ�(�Ǹ�)			�ֹ���ȣ
sql.append(" where st_goodsCode = order_GoodsCode and order_Code =?)");


// ��ǰ ��ȣ
sql.append(" where st_goodsCode =? ");*/

