package Controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.time.LocalDate;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;

import Model.ItemInfoVO;
import Model.ItemStockVO;
import Model.OrderVO;
import Model.StockEdit_ListVO;
import Model.StockEdit_List_DelVO;
import Model.StockEdit_List_AddVO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ItemInfoController implements Initializable {

	@FXML
	private Button btn_SaveExcel;
	@FXML
	private Button btn_SaveFile_Dir;
	@FXML
	private TextField txt_SaveFile_Dir;
	@FXML
	private Button btn_SavePDF;


	// ��1
	// ���̺� ��
	@FXML
	private TableView<ItemStockVO> tableView_ItemList = new TableView<>();

	@FXML
	private TableView<StockEdit_ListVO> tableView_StockEdit = new TableView<>();

	@FXML
	private TableView<StockEdit_List_AddVO> tableView_StockEdit_Add = new TableView<>();

	@FXML
	private TableView<StockEdit_List_DelVO> tableView_StockEdit_Del = new TableView<>();

	// �ؽ�Ʈ �ʵ�

	@FXML
	private TextField txt_ItemStock_GoodsSearch; // �˻�

	// �޺��ڽ�
	@FXML
	private ComboBox<String> cb_ItemStock_Main;
	/*
	 * @FXML private ComboBox<String> cb_ItemStock_Sub;
	 */

	// ��ư
	@FXML
	private Button btn_ItemStock_select_Search;
	@FXML
	private Button btn_ItemStock_Search;
	@FXML
	private Button btn_ItemStock_Edit;
	@FXML
	private Button btn_ItemStock_Exit;
	@FXML
	private Button btn_ItemStock_Reset;

	@FXML
	private Button btn_ItemStock_Edit_Add;
	@FXML
	private Button btn_ItemStock_Edit_Del;
	@FXML
	private Button btn_ItemStock_Edit_Cancel;

	// ��
	@FXML
	private Tab StockList;

	// ��2
	// ���̺� ��
	@FXML
	private TableView<ItemInfoVO> tableView = new TableView<>();

	// �޺��ڽ�
	@FXML
	private ComboBox<String> cb_MainCategory;
	@FXML
	private ComboBox<String> cb_SubCategory;

	// �ؽ�Ʈ �ʵ�
	@FXML
	private TextField txt_ItemInfo_Search; // �˻�

	@FXML
	private TextField txt_GoodsCode; // ��ǰ�ڵ�
	@FXML
	private TextField txt_GoodsName; // ǰ��
	@FXML
	private TextField txt_GoodsColor; // ����
	@FXML
	private TextField txt_GoodsSize; // ������
	@FXML
	private TextField txt_GoodsQuantity; // ����
	@FXML
	private TextField txt_GoodsPrice; // �ܰ�
	@FXML
	private TextField txt_GoodsSalesPrice;; // �ǸŰ�

	// �ؽ�Ʈ ������
	@FXML
	private TextArea txt_GoodsRemarks; // ���

	// ��ư
	@FXML
	private Button btn_ItemInfo_Search;
	@FXML
	private Button btn_ItemInfo_Add;
	@FXML
	private Button btn_ItemInfo_Edit;
	@FXML
	private Button btn_ItemInfo_Delete;
	@FXML
	private Button btn_ItemInfo_Cancel;
	@FXML
	private Button btn_ItemInfo_Reset;
	@FXML
	private Button btnImageFile;

	// �̹����ڽ�
	@FXML
	private HBox imageBox;

	// �̹��� ��
	@FXML
	private ImageView imageView;

	private Stage primaryStage;
	String selectFileName = ""; // �̹��� ���ϸ�
	String localUrl = ""; // �̹��� ���� ���
	Image localImage;

	int selectedIndex; // ���̺����� ������ ��ǰ ���� �ε��� ����
	int goodsCode; // ������ ���̺����� ������ ��ǰ�� ��ȣ ����
	int iStockEdit_Edit_Code;
	int st_goodsCode;

	File selectedFile = null;

	// ���̺����� ������ ���� ����
	ObservableList<ItemInfoVO> data = FXCollections.observableArrayList();
	ObservableList<ItemInfoVO> selectGoods = null;
	ItemInfoVO student = new ItemInfoVO();

	ObservableList<ItemStockVO> stockdata = FXCollections.observableArrayList();
	ObservableList<ItemStockVO> stockGoods = null;
	ItemStockVO stock = new ItemStockVO();

	ObservableList<StockEdit_ListVO> stockListdata = FXCollections.observableArrayList();
	ObservableList<StockEdit_ListVO> StockEditGoods = null;
	StockEdit_ListVO stockEdit = new StockEdit_ListVO();

	ObservableList<StockEdit_List_DelVO> stockList_Deldata = FXCollections.observableArrayList();
	ObservableList<StockEdit_List_DelVO> StockEdit_DelGoods = null;
	StockEdit_ListVO stockEdit_Del = new StockEdit_ListVO();

	ObservableList<StockEdit_List_AddVO> stockList_Adddata = FXCollections.observableArrayList();
	ObservableList<StockEdit_List_AddVO> StockEdit_AddGoods = null;
	StockEdit_ListVO stockEdit_Add = new StockEdit_ListVO();

	// �̹��� ó��
	// �̹��� ������ ������ �Ű������� ���� ��ü ����
	private File dirSave = new File("C:/images");
	// �̹��� �ҷ��� ������ ������ ���� ��ü ����
	private File file = null;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		
		// ������ ��Ŀ ���� pdf�� �����ϴ� ����� �츮�� �ؾ���

		tableView_ItemList.setOnMousePressed(event -> {
			try {
				stockGoods = tableView_ItemList.getSelectionModel().getSelectedItems();
				selectedIndex = tableView_ItemList.getSelectionModel().getSelectedIndex();
				goodsCode = stockGoods.get(0).getGoodsCode();

			} catch (Exception e) {

			}
		});

		// ��з� �޺� �� ����
		cb_ItemStock_Main.setItems(FXCollections.observableArrayList("��ü", "�Ƿ�", "�Ź�", "ACC"));
		/*
		 * cb_ItemStock_Sub .setItems(FXCollections.observableArrayList("����", "����",
		 * "�ƿ���", "�ο�", "�̵�", "����", "����", "����", "��Ÿ"));
		 * cb_ItemStock_Sub.setDisable(true);
		 */

		cb_MainCategory.setItems(FXCollections.observableArrayList("�Ƿ�", "�Ź�", "ACC"));
		cb_SubCategory
				.setItems(FXCollections.observableArrayList("����", "����", "�ƿ���", "�ο�", "�̵�", "����", "����", "����", "��Ÿ"));
		cb_SubCategory.setDisable(true);

		// setOnAction ���� �޺� �ڽ��� �̺�Ʈ�� �ְ� getSelectionModel()�� getSelectedItem()�� equals
		// �� ���� ���� ���ð�� if������ ���� �޺� �ڽ��� ���� ���� �Ǵ� ������ �ִ�.
		cb_MainCategory.setOnAction(event -> {
			try {
				if (cb_MainCategory.getSelectionModel().getSelectedItem().equals("�Ƿ�")) {
					cb_SubCategory.setDisable(false);
					cb_SubCategory.setItems(FXCollections.observableArrayList("����", "����", "�ƿ���"));
				}
				if (cb_MainCategory.getSelectionModel().getSelectedItem().equals("�Ź�")) {
					cb_SubCategory.setDisable(false);
					cb_SubCategory.setItems(FXCollections.observableArrayList("�ο�", "�̵�", "����"));
				}
				if (cb_MainCategory.getSelectionModel().getSelectedItem().equals("ACC")) {
					cb_SubCategory.setDisable(false);
					cb_SubCategory.setItems(FXCollections.observableArrayList("����", "����", "��Ÿ"));
				}
			} catch (Exception e) {
			}

		});

		cb_ItemStock_Main.setOnAction(event -> {
			try {
				if (cb_ItemStock_Main.getSelectionModel().getSelectedItem().equals("��ü")) {
					/* cb_ItemStock_Sub.setDisable(true); */
				}
				if (cb_ItemStock_Main.getSelectionModel().getSelectedItem().equals("�Ƿ�")) {
					/*
					 * cb_ItemStock_Sub.setDisable(false);
					 * cb_ItemStock_Sub.setItems(FXCollections.observableArrayList("����", "����",
					 * "�ƿ���"));
					 */
				}
				if (cb_ItemStock_Main.getSelectionModel().getSelectedItem().equals("�Ź�")) {
					/*
					 * cb_ItemStock_Sub.setDisable(false);
					 * cb_ItemStock_Sub.setItems(FXCollections.observableArrayList("�ο�", "�̵�",
					 * "����"));
					 */
				}
				if (cb_ItemStock_Main.getSelectionModel().getSelectedItem().equals("ACC")) {
					/*
					 * cb_ItemStock_Sub.setDisable(false);
					 * cb_ItemStock_Sub.setItems(FXCollections.observableArrayList("����", "����",
					 * "��Ÿ"));
					 */
				}
			} catch (Exception e) {
			}

		});

		// �� 2 ��ǰ ���� ���̺� �� �÷��̸� ����
		TableColumn colGoodsCode = new TableColumn("��ǰ�ڵ�");
		colGoodsCode.setMinWidth(40);
		colGoodsCode.setStyle("-fx-allignment: CENTER");
		colGoodsCode.setCellValueFactory(new PropertyValueFactory<>("goodsCode"));

		TableColumn colGoodsName = new TableColumn("��ǰ��");
		colGoodsName.setMinWidth(60);
		colGoodsName.setStyle("-fx-allignment: CENTER");
		colGoodsName.setCellValueFactory(new PropertyValueFactory<>("goodsName"));

		TableColumn colMainCategory = new TableColumn("��з�");
		colMainCategory.setMinWidth(40);
		colMainCategory.setStyle("-fx-allignment: CENTER");
		colMainCategory.setCellValueFactory(new PropertyValueFactory<>("mainCategory"));

		TableColumn colSubCategory = new TableColumn("�Һз�");
		colSubCategory.setMinWidth(40);
		colSubCategory.setStyle("-fx-allignment: CENTER");
		colSubCategory.setCellValueFactory(new PropertyValueFactory<>("subCategory"));

		TableColumn colSGoodsColor = new TableColumn("����");
		colSGoodsColor.setMinWidth(40);
		colSGoodsColor.setStyle("-fx-allignment: CENTER");
		colSGoodsColor.setCellValueFactory(new PropertyValueFactory<>("goodsColor"));

		TableColumn colGoodsSize = new TableColumn("������");
		colGoodsSize.setMinWidth(40);
		colGoodsSize.setStyle("-fx-allignment: CENTER");
		colGoodsSize.setCellValueFactory(new PropertyValueFactory<>("goodsSize"));

		TableColumn colGoodsPrice = new TableColumn("�ܰ�");
		colGoodsPrice.setMinWidth(40);
		colGoodsPrice.setStyle("-fx-allignment: CENTER");
		colGoodsPrice.setCellValueFactory(new PropertyValueFactory<>("goodsPrice"));

		TableColumn colGoodsSalesPrice = new TableColumn("�ǸŰ�");
		colGoodsSalesPrice.setMinWidth(40);
		colGoodsSalesPrice.setStyle("-fx-allignment: CENTER");
		colGoodsSalesPrice.setCellValueFactory(new PropertyValueFactory<>("goodsSalesPrice"));

		TableColumn colGoodsRemarks = new TableColumn("���");
		colGoodsRemarks.setMinWidth(40);
		colGoodsRemarks.setStyle("-fx-allignment: CENTER");
		colGoodsRemarks.setCellValueFactory(new PropertyValueFactory<>("goodsRemarks"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colGoodsCode, colGoodsName, colMainCategory, colSubCategory, colSGoodsColor,
				colGoodsSize, colGoodsPrice, colGoodsSalesPrice, colGoodsRemarks);

		// �� 1 ��� ����Ʈ ���̺� �� �÷��̸� ����
		TableColumn colStock_GoodsCode = new TableColumn("��ǰ�ڵ�");
		colStock_GoodsCode.setMinWidth(40);
		colStock_GoodsCode.setStyle("-fx-allignment: CENTER");
		colStock_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("goodsCode"));

		TableColumn colStock_GoodsName = new TableColumn("��ǰ��");
		colStock_GoodsName.setMinWidth(60);
		colStock_GoodsName.setStyle("-fx-allignment: CENTER");
		colStock_GoodsName.setCellValueFactory(new PropertyValueFactory<>("goodsName"));

		TableColumn colStock_MainCategory = new TableColumn("��з�");
		colStock_MainCategory.setMinWidth(40);
		colStock_MainCategory.setStyle("-fx-allignment: CENTER");
		colStock_MainCategory.setCellValueFactory(new PropertyValueFactory<>("mainCategory"));

		TableColumn colStock_SubCategory = new TableColumn("�Һз�");
		colStock_SubCategory.setMinWidth(40);
		colStock_SubCategory.setStyle("-fx-allignment: CENTER");
		colStock_SubCategory.setCellValueFactory(new PropertyValueFactory<>("subCategory"));

		TableColumn colStock_GoodsColor = new TableColumn("����");
		colStock_GoodsColor.setMinWidth(40);
		colStock_GoodsColor.setStyle("-fx-allignment: CENTER");
		colStock_GoodsColor.setCellValueFactory(new PropertyValueFactory<>("goodsColor"));

		TableColumn colStock_GoodsSize = new TableColumn("������");
		colStock_GoodsSize.setMinWidth(40);
		colStock_GoodsSize.setStyle("-fx-allignment: CENTER");
		colStock_GoodsSize.setCellValueFactory(new PropertyValueFactory<>("goodsSize"));

		TableColumn colStock_GoodsQuantity = new TableColumn("����");
		colStock_GoodsQuantity.setMinWidth(40);
		colStock_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colStock_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("goodsQuantity"));

		TableColumn colStock_GoodsPrice = new TableColumn("�ܰ�");
		colStock_GoodsPrice.setMinWidth(40);
		colStock_GoodsPrice.setStyle("-fx-allignment: CENTER");
		colStock_GoodsPrice.setCellValueFactory(new PropertyValueFactory<>("goodsPrice"));

		TableColumn colStock_GoodsSalesPrice = new TableColumn("�ǸŰ�");
		colStock_GoodsSalesPrice.setMinWidth(40);
		colStock_GoodsSalesPrice.setStyle("-fx-allignment: CENTER");
		colStock_GoodsSalesPrice.setCellValueFactory(new PropertyValueFactory<>("goodsSalesPrice"));

		tableView_ItemList.setItems(stockdata);
		tableView_ItemList.getColumns().addAll(colStock_GoodsCode, colStock_GoodsName, colStock_MainCategory,
				colStock_SubCategory, colStock_GoodsColor, colStock_GoodsSize, colStock_GoodsQuantity,
				colStock_GoodsPrice, colStock_GoodsSalesPrice);

		// �� 1 ��� ����Ʈ ���� ���̺� �� �÷��̸� ����
		TableColumn colIStockEdit_Edit_Code = new TableColumn("��ȣ");
		colIStockEdit_Edit_Code.setMinWidth(30);
		colIStockEdit_Edit_Code.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Code.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Code"));

		TableColumn colIStockEdit_Edit_Date = new TableColumn("���� ����");
		colIStockEdit_Edit_Date.setMinWidth(30);
		colIStockEdit_Edit_Date.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Date.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Date"));

		TableColumn colIStockEdit_GoodsCode = new TableColumn("��ǰ �ڵ�");
		colIStockEdit_GoodsCode.setMinWidth(40);
		colIStockEdit_GoodsCode.setStyle("-fx-allignment: CENTER");
		colIStockEdit_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("stockEdit_GoodsCode"));

		TableColumn colIStockEdit_GoodsName = new TableColumn("��ǰ ��");
		colIStockEdit_GoodsName.setMinWidth(40);
		colIStockEdit_GoodsName.setStyle("-fx-allignment: CENTER");
		colIStockEdit_GoodsName.setCellValueFactory(new PropertyValueFactory<>("stockEdit_GoodsName"));

		TableColumn colIStockEdit_GoodsQuantity = new TableColumn("����");
		colIStockEdit_GoodsQuantity.setMinWidth(30);
		colIStockEdit_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colIStockEdit_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("stockEdit_GoodsQuantity"));

		TableColumn colIStockEdit_Edit_Remarks_Edit_Remarks = new TableColumn("���� ����");
		colIStockEdit_Edit_Remarks_Edit_Remarks.setMinWidth(200);
		colIStockEdit_Edit_Remarks_Edit_Remarks.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Remarks_Edit_Remarks
				.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Remarks"));

		tableView_StockEdit.setItems(stockListdata);
		tableView_StockEdit.getColumns().addAll(colIStockEdit_Edit_Code, colIStockEdit_Edit_Date,
				colIStockEdit_GoodsCode, colIStockEdit_GoodsName, colIStockEdit_GoodsQuantity,
				colIStockEdit_Edit_Remarks_Edit_Remarks);

		// �� 1 ��� ����Ʈ ���� �డ ���̺� �� �÷��̸� ����
		TableColumn colIStockEdit_Edit_Add_Code = new TableColumn("��ȣ");
		colIStockEdit_Edit_Add_Code.setMinWidth(30);
		colIStockEdit_Edit_Add_Code.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Add_Code.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Add_Code"));

		TableColumn colIStockEdit_Edit_Add_Date = new TableColumn("���� ����");
		colIStockEdit_Edit_Add_Date.setMinWidth(30);
		colIStockEdit_Edit_Add_Date.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Add_Date.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Add_Edit_Date"));

		TableColumn colIStockEdit_Add_GoodsCode = new TableColumn("��ǰ �ڵ�");
		colIStockEdit_Add_GoodsCode.setMinWidth(40);
		colIStockEdit_Add_GoodsCode.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Add_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Add_GoodsCode"));

		TableColumn colIStockEdit_Add_GoodsName = new TableColumn("��ǰ ��");
		colIStockEdit_Add_GoodsName.setMinWidth(40);
		colIStockEdit_Add_GoodsName.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Add_GoodsName.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Add_GoodsName"));

		TableColumn colIStockEdit_Add_GoodsQuantity = new TableColumn("����");
		colIStockEdit_Add_GoodsQuantity.setMinWidth(30);
		colIStockEdit_Add_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Add_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Add_GoodsQuantity"));

		TableColumn colIStockEdit_Edit_Adds_Remarks = new TableColumn("���� ����");
		colIStockEdit_Edit_Adds_Remarks.setMinWidth(200);
		colIStockEdit_Edit_Adds_Remarks.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Adds_Remarks.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Add_Remarks"));

		tableView_StockEdit_Add.setItems(stockList_Adddata);
		tableView_StockEdit_Add.getColumns().addAll(colIStockEdit_Edit_Add_Code, colIStockEdit_Edit_Add_Date,
				colIStockEdit_Add_GoodsCode, colIStockEdit_Add_GoodsName, colIStockEdit_Add_GoodsQuantity,
				colIStockEdit_Edit_Adds_Remarks);

		// �� 1 ��� ����Ʈ ���� ���� ���̺� �� �÷��̸� ����
		TableColumn colIStockEdit_Edit_Del_Code = new TableColumn("��ȣ");
		colIStockEdit_Edit_Del_Code.setMinWidth(30);
		colIStockEdit_Edit_Del_Code.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Del_Code.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Del_Code"));

		TableColumn colIStockEdit_Edit_Del_Date = new TableColumn("���� ����");
		colIStockEdit_Edit_Del_Date.setMinWidth(30);
		colIStockEdit_Edit_Del_Date.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Del_Date.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Del_Date"));

		TableColumn colIStockEdit_Del_GoodsCode = new TableColumn("��ǰ �ڵ�");
		colIStockEdit_Del_GoodsCode.setMinWidth(40);
		colIStockEdit_Del_GoodsCode.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Del_GoodsCode.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Del_GoodsCode"));

		TableColumn colIStockEdit_Del_GoodsName = new TableColumn("��ǰ ��");
		colIStockEdit_Del_GoodsName.setMinWidth(40);
		colIStockEdit_Del_GoodsName.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Del_GoodsName.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Del_GoodsName"));

		TableColumn colIStockEdit_Del_GoodsQuantity = new TableColumn("����");
		colIStockEdit_Del_GoodsQuantity.setMinWidth(30);
		colIStockEdit_Del_GoodsQuantity.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Del_GoodsQuantity.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Del_GoodsQuantity"));

		TableColumn colIStockEdit_Edit_Del_Remarks = new TableColumn("���� ����");
		colIStockEdit_Edit_Del_Remarks.setMinWidth(200);
		colIStockEdit_Edit_Del_Remarks.setStyle("-fx-allignment: CENTER");
		colIStockEdit_Edit_Del_Remarks.setCellValueFactory(new PropertyValueFactory<>("stockEdit_Edit_Del_Remarks"));

		tableView_StockEdit_Del.setItems(stockList_Deldata);
		tableView_StockEdit_Del.getColumns().addAll(colIStockEdit_Edit_Del_Code, colIStockEdit_Edit_Del_Date,
				colIStockEdit_Del_GoodsCode, colIStockEdit_Del_GoodsName, colIStockEdit_Del_GoodsQuantity,
				colIStockEdit_Edit_Del_Remarks);

		// �⺻ �̹���
		localUrl = "/images/default.png";
		localImage = new Image(localUrl, false);
		imageView.setImage(localImage);

		// ��ǰ ��ü ����
		totalList();

		// ��� ��ü ���� ����
		totalStockList();

		// ��� ���� ���� ����Ʈ ����
		totalEditList();

		// ��� ���� �߰� ���� ����Ʈ ����
		totalEditList_Add();
		// ��� ���� �߰� ���� ����Ʈ ����
		totalEditList_Del();

		// �� 1 ��ư
		btn_ItemStock_select_Search.setOnAction(event -> handlerBtn_ItemStock_select_SearchActoion(event)); // �޺��ڽ� ��ȸ
		btn_ItemStock_Search.setOnAction(event -> handlerBtn_ItemStock_SearchActoion(event)); // Ž��
		btn_ItemStock_Exit.setOnAction(event -> handlerBtn_ItemStock_ExitActoion(event)); // �ݱ�
		btn_ItemStock_Reset.setOnAction(event -> handlerBtn_ItemStock_ResetActoion(event)); // �ʱ�ȭ

		btn_ItemStock_Edit.setOnAction(event -> handlerBtn_ItemStock_EditActoion(event)); // �������
		btn_ItemStock_Edit_Add.setOnMouseClicked(event -> handlerBtn_ItemStock_Edit_AddActoion(event));
		btn_ItemStock_Edit_Del.setOnMouseClicked(event -> handlerBtn_ItemStock_Edit_DelActoion(event));
		btn_ItemStock_Edit_Cancel.setOnAction(event -> handlerBtn_ItemStock_Edit_CancelActoion(event));

		// �� 2 ��ư
		btn_ItemInfo_Add.setOnAction(event -> handlerBtn_ItemInfo_AddActoion(event)); // ����
		btn_ItemInfo_Edit.setOnAction(event -> handlerBtn_ItemInfo_EditActoion(event)); // ����
		btn_ItemInfo_Delete.setOnAction(event -> handlerBtn_ItemInfo_DeleteActoion(event)); // ����
		btn_ItemInfo_Cancel.setOnAction(event -> handlerBtn_ItemInfo_CancelActoion(event)); // �ݱ�
		btn_ItemInfo_Search.setOnAction(event -> handlerBtn_ItemInfo_SearchActoion(event)); // �˻�
		btn_ItemInfo_Reset.setOnAction(event -> handlerBtn_ItemInfo_ResetActoion(event)); // �ʱ�ȭ
		btnImageFile.setOnAction(event -> handlerBtnImageFileActoion(event)); // �̹�������â

		btn_SaveExcel.setOnAction(event -> handlerBtn_SaveExcelActoion(event)); // �������ϻ���
		btn_SaveFile_Dir.setOnAction(event -> handlerBtn_SaveFile_DirActoion(event)); // ������������
		//btn_SavePDF.setOnAction(event -> handlerBtn_SavePDFActoion(event)); // PDF���ϻ���

		tableView.setOnMousePressed(event -> {
			try {
				selectGoods = tableView.getSelectionModel().getSelectedItems();
				selectedIndex = tableView.getSelectionModel().getSelectedIndex();
				goodsCode = selectGoods.get(0).getGoodsCode();

				txt_GoodsCode.setDisable(true);
				txt_GoodsCode.setText(selectGoods.get(0).getGoodsCode() + "");
				txt_GoodsName.setText(selectGoods.get(0).getGoodsName());

				// ��� Ŭ���� �޺� �ڽ��� �ε��� 0���� ���� �Ǿ� �ִ� �κ� ���� �ʿ� - 11.13
				cb_MainCategory.setValue(tableView.getSelectionModel().getSelectedItem().getMainCategory());
				/*
				 * // ������ �� - �޺��ڽ� ���� ���ǹ� if
				 * (cb_MainCategory.getSelectionModel().getSelectedItem().equals("�Ƿ�")) {
				 * cb_SubCategory.setDisable(false);
				 * cb_SubCategory.setItems(FXCollections.observableArrayList("����", "����",
				 * "�ƿ���")); } if
				 * (cb_MainCategory.getSelectionModel().getSelectedItem().equals("�Ź�")) {
				 * cb_SubCategory.setDisable(false);
				 * cb_SubCategory.setItems(FXCollections.observableArrayList("�ο�", "�̵�", "����"));
				 * } if (cb_MainCategory.getSelectionModel().getSelectedItem().equals("ACC")) {
				 * cb_SubCategory.setDisable(false);
				 * cb_SubCategory.setItems(FXCollections.observableArrayList("����", "����", "��Ÿ"));
				 * } //
				 */ cb_SubCategory.setValue(tableView.getSelectionModel().getSelectedItem().getSubCategory());

				txt_GoodsColor.setText(selectGoods.get(0).getGoodsColor() + "");
				txt_GoodsSize.setText(selectGoods.get(0).getGoodsSize() + "");
				txt_GoodsPrice.setText(selectGoods.get(0).getGoodsPrice() + "");
				txt_GoodsSalesPrice.setText(selectGoods.get(0).getGoodsSalesPrice() + "");
				txt_GoodsRemarks.setText(selectGoods.get(0).getGoodsRemarks());

				// �̹��� ����
				selectFileName = selectGoods.get(0).getFilename();
				if (selectFileName != null) {
					localUrl = "file:/C:/images/" + selectFileName;
					localImage = new Image(localUrl, false);
					imageView.setImage(localImage);
				} else {
					localUrl = "/images/default.png";
					localImage = new Image(localUrl, false);
					imageView.setImage(localImage);
				}

			} catch (Exception e) {
			}

		});

	}

	// ���� PDF �߰�
	// ���� ���� ���� ����
	public void handlerBtn_SaveFile_DirActoion(ActionEvent event) {
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File selectedDirectory = directoryChooser.showDialog(primaryStage);
		if (selectedDirectory != null) {
			txt_SaveFile_Dir.setText(selectedDirectory.getAbsolutePath());
			btn_SaveExcel.setDisable(false);
			btn_SavePDF.setDisable(false);
		}

	}

	// ���� ���� ����
	public void handlerBtn_SaveExcelActoion(ActionEvent event) {
		ItemStockDAO sDao = new ItemStockDAO();
		boolean saveSuccess;

		ArrayList<ItemStockVO> list;
		list = sDao.getItemStockTotal();
		ItemStockExcel excelWriter = new ItemStockExcel();

		// xlsx ���� ����
		saveSuccess = excelWriter.xlsxWiter(list, txt_SaveFile_Dir.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���� ����");
			alert.setHeaderText("�л� ��� ���� ���� ���� ����.");
			alert.setContentText("��� ��� ���� ����.");
			alert.showAndWait();
		}
		txt_SaveFile_Dir.clear();
		btn_SaveExcel.setDisable(true);
		btn_SavePDF.setDisable(true);

	}

	/*// PDF ���� - �Ⱓ�� �۾� �Ұ� ���� �߻� (���� ����)
	public void handlerBtn_SavePDFActoion(ActionEvent event) {
		try {
			FXMLLoader loaderPdf = new FXMLLoader();
			loaderPdf.setLocation(getClass().getResource("/View/pdfImage.fxml"));

			Stage dialogPdf = new Stage(StageStyle.UTILITY);
			dialogPdf.initModality(Modality.WINDOW_MODAL);
			dialogPdf.initOwner(btn_SavePDF.getScene().getWindow());
			dialogPdf.setTitle("�������Ʈ PDF ��Ʈ �̹��� ����");

			Parent parentPdf = (Parent) loaderPdf.load();

			Button btnPdfSave = (Button) parentPdf.lookup("#btnPdfSave");
			CheckBox cbBarImage = (CheckBox) parentPdf.lookup("#cbBarImage");
			CheckBox cbPieImage = (CheckBox) parentPdf.lookup("#cbPieImage");

			Scene scene = new Scene(parentPdf);
			dialogPdf.setScene(scene);
			dialogPdf.setResizable(false);
			dialogPdf.show();

			btnPdfSave.setOnAction(e -> {

				try {
					// pdf document ����.
					// (Rectangle pageSize, float marginLeft, float
					// marginRight, float
					// marginTop, float marginBottom)
					Document document = new Document(PageSize.A4, 0, 0, 30, 30);

					// pdf ������ ������ ������ ����. pdf������ �����ȴ�. ���� ��Ʈ������ ����.
					String strReportPDFName = "itemStock(NB)_" + System.currentTimeMillis() + ".pdf";
					PdfWriter.getInstance(document,
							new FileOutputStream(txt_SaveFile_Dir.getText() + "\\" + strReportPDFName));

					// document�� ���� pdf������ �����ֵ����Ѵ�..
					document.open();

					// �ѱ�������Ʈ ����..
					BaseFont bf = BaseFont.createFont("font/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

					Font font = new Font(bf, 8, Font.NORMAL);
					Font font2 = new Font(bf, 14, Font.BOLD);

					// Ÿ��Ʋ
					Paragraph title = new Paragraph("�л� ����ǥ", font2);

					// �߰�����
					title.setAlignment(Element.ALIGN_CENTER);

					// ������ �߰�
					document.add(title);
					document.add(new Paragraph("\r\n"));

					// ���� ��¥

					// ������ ����

					// ������ �߰�

					// ������ �߰�

					// ���̺����� Table��ü���� PdfPTable��ü�� �� �����ϰ� ���̺��� ����� �ִ�.
					// �����ڿ� �÷����� ���ش�.
					PdfPTable table = new PdfPTable(11);

					// ������ �÷��� width�� ���Ѵ�.
					table.setWidths(new int[] { 50, 50, 30, 30, 30, 30, 30, 50, 50, 70, 200 });

					// �÷� Ÿ��Ʋ..
					PdfPCell header1 = new PdfPCell(new Paragraph("��ǰ�ڵ�", font));
					PdfPCell header2 = new PdfPCell(new Paragraph("��ǰ��", font));
					PdfPCell header3 = new PdfPCell(new Paragraph("��з�", font));
					PdfPCell header4 = new PdfPCell(new Paragraph("�Һз�", font));
					PdfPCell header5 = new PdfPCell(new Paragraph("����", font));
					PdfPCell header6 = new PdfPCell(new Paragraph("������", font));
					PdfPCell header7 = new PdfPCell(new Paragraph("����", font));
					PdfPCell header8 = new PdfPCell(new Paragraph("��ǰ�ܰ�", font));
					PdfPCell header9 = new PdfPCell(new Paragraph("�ǸŴܰ�", font));
					PdfPCell header10 = new PdfPCell(new Paragraph("���", font));
					PdfPCell header11 = new PdfPCell(new Paragraph("�̹���", font));

					// ��������
					header1.setHorizontalAlignment(Element.ALIGN_CENTER);
					header2.setHorizontalAlignment(Element.ALIGN_CENTER);
					header3.setHorizontalAlignment(Element.ALIGN_CENTER);
					header4.setHorizontalAlignment(Element.ALIGN_CENTER);
					header5.setHorizontalAlignment(Element.ALIGN_CENTER);
					header6.setHorizontalAlignment(Element.ALIGN_CENTER);
					header7.setHorizontalAlignment(Element.ALIGN_CENTER);
					header8.setHorizontalAlignment(Element.ALIGN_CENTER);
					header9.setHorizontalAlignment(Element.ALIGN_CENTER);
					header10.setHorizontalAlignment(Element.ALIGN_CENTER);
					header11.setHorizontalAlignment(Element.ALIGN_CENTER);

					// ��������
					header1.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header2.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header3.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header4.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header5.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header6.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header7.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header8.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header9.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header10.setVerticalAlignment(Element.ALIGN_MIDDLE);
					header11.setVerticalAlignment(Element.ALIGN_MIDDLE);

					// ���̺��� �߰�..
					table.addCell(header1);
					table.addCell(header2);
					table.addCell(header3);
					table.addCell(header4);
					table.addCell(header5);
					table.addCell(header6);
					table.addCell(header7);
					table.addCell(header8);
					table.addCell(header9);
					table.addCell(header10);
					table.addCell(header11);

					// DB ���� �� ����Ʈ ����
					ItemStockDAO iDao = new ItemStockDAO();
					ItemStockVO iVo = new ItemStockVO();
					ArrayList<ItemStockVO> list;
					list = iDao.getItemStockTotal();
					int rowCount = list.size();

					PdfPCell cell1 = null;
					PdfPCell cell2 = null;
					PdfPCell cell3 = null;
					PdfPCell cell4 = null;
					PdfPCell cell5 = null;
					PdfPCell cell6 = null;
					PdfPCell cell7 = null;
					PdfPCell cell8 = null;
					PdfPCell cell9 = null;
					PdfPCell cell10 = null;
					PdfPCell cell11 = null;

					for (int index = 0; index < rowCount; index++) {
						iVo = list.get(index);
						cell1 = new PdfPCell(new Paragraph(iVo.getGoodsCode() + "", font));
						cell2 = new PdfPCell(new Paragraph(iVo.getGoodsName(), font));
						cell3 = new PdfPCell(new Paragraph(iVo.getMainCategory(), font));
						cell4 = new PdfPCell(new Paragraph(iVo.getSubCategory(), font));
						cell5 = new PdfPCell(new Paragraph(iVo.getGoodsColor() + "", font));
						cell6 = new PdfPCell(new Paragraph(iVo.getGoodsSize() + "", font));
						cell7 = new PdfPCell(new Paragraph(iVo.getGoodsQuantity() + "", font));
						cell8 = new PdfPCell(new Paragraph(iVo.getGoodsPrice() + "", font));
						cell9 = new PdfPCell(new Paragraph(iVo.getGoodsSalesPrice() + "", font));
						cell10 = new PdfPCell(new Paragraph(iVo.getGoodsRemarks(), font));
						cell11 = new PdfPCell(new Paragraph(iVo.getFilename(), font));

						// ��������
						cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell11.setHorizontalAlignment(Element.ALIGN_CENTER);

						// ��������
						cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
						cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);

						// ���̺��� �� �߰�
						table.addCell(cell1);
						table.addCell(cell2);
						table.addCell(cell3);
						table.addCell(cell4);
						table.addCell(cell5);
						table.addCell(cell6);
						table.addCell(cell7);
						table.addCell(cell8);
						table.addCell(cell9);
						table.addCell(cell10);
						table.addCell(cell11);

					}

					document.add(table);
					document.add(new Paragraph("\r\n"));
					Alert alert = new Alert(AlertType.INFORMATION);

					if (cbBarImage.isSelected() && cbPieImage.isSelected()) {
						Paragraph barImageTitle = new Paragraph("��� ��� ���� �׷���", font);
						barImageTitle.setAlignment(Element.ALIGN_CENTER);
						document.add(barImageTitle);
						document.add(new Paragraph("\r\n"));
						final String barImageUrl = "chartImage/ItemStockBarChart.png";
						// ������ javafx.scene.image.Image ��ü�� ����ϰ� �־� �浹�� ���� �Ʒ��� ���� �����.
						com.itextpdf.text.Image barImage;
						try {
							if (com.itextpdf.text.Image.getInstance(barImageUrl) != null) {
								barImage = com.itextpdf.text.Image.getInstance(barImageUrl);
								barImage.setAlignment(Element.ALIGN_CENTER);
								barImage.scalePercent(30f);
								document.add(barImage);
								document.add(new Paragraph("\r\n"));
							}
						} catch (IOException ee) {
						}

						// ���� �׷��� �̹��� �߰�
						Paragraph pieImageTitle1 = new Paragraph("��� ��� ���� �׷���", font);
						pieImageTitle1.setAlignment(Element.ALIGN_CENTER);
						document.add(pieImageTitle1);
						document.add(new Paragraph("\r\n"));
						final String pieImageUrl = "chartImage/ItemStockPieChart.png";
						com.itextpdf.text.Image pieImage;

						try {
							if (com.itextpdf.text.Image.getInstance(pieImageUrl) != null) {
								pieImage = com.itextpdf.text.Image.getInstance(pieImageUrl);
								pieImage.setAlignment(Element.ALIGN_CENTER);
								pieImage.scalePercent(30f);
								document.add(pieImage);
							}
						} catch (IOException ee) {
						}

					} else if (cbBarImage.isSelected()) {
						// ���� �׷��� �̹��� �߰�
						Paragraph barImageTitle = new Paragraph("��� ��� ���� �׷���", font);
						barImageTitle.setAlignment(Element.ALIGN_CENTER);
						document.add(barImageTitle);
						document.add(new Paragraph("\r\n"));
						final String barImageUrl = "chartImage/ItemStockBarChart.png";
						com.itextpdf.text.Image barImage;
						try {
							if (com.itextpdf.text.Image.getInstance(barImageUrl) != null) {
								barImage = com.itextpdf.text.Image.getInstance(barImageUrl);
								barImage.setAlignment(Element.ALIGN_CENTER);
								barImage.scalePercent(30f);
								document.add(barImage);
							}
						} catch (IOException ee) {
						}
					} else if (cbPieImage.isSelected()) {
						// ���� �׷��� �̹��� �߰�
						Paragraph pieImageTitle1 = new Paragraph("��� ��� ���� �׷���", font);
						pieImageTitle1.setAlignment(Element.ALIGN_CENTER);
						document.add(pieImageTitle1);
						document.add(new Paragraph("\r\n"));
						final String pieImageUrl = "chartImage/ItemStockPieChart.png";
						com.itextpdf.text.Image pieImage;
						try {
							if (com.itextpdf.text.Image.getInstance(pieImageUrl) != null) {
								pieImage = com.itextpdf.text.Image.getInstance(pieImageUrl);
								pieImage.setAlignment(Element.ALIGN_CENTER);
								pieImage.scalePercent(30f);
								document.add(pieImage);

							}
						} catch (IOException ee) {
						}
					}

					// ������ �ݴ´�.. ���� ����..
					document.close();

					dialogPdf.close();
					txt_SaveFile_Dir.clear();
					btn_SavePDF.setDisable(true);
					btn_SaveExcel.setDisable(true);

					alert.setTitle("PDF ���� ����");
					alert.setHeaderText("��ǰ ��� PDF ���� ���� ����.");
					alert.setContentText("��ǰ ��� PDF ����.");
					alert.showAndWait();

				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (DocumentException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			});

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
*/
	// �� 1 ��° ��ǰ ��� ����Ʈ
	// �������Ʈ ��ü ����Ʈ
	public void totalStockList() {
		Object[][] totalStockData;

		ItemStockDAO iDao = new ItemStockDAO();
		ItemStockVO iVo = null;
		ArrayList<String> title;
		ArrayList<ItemStockVO> list;

		title = iDao.getColumnName();
		int columnCount = title.size();

		list = iDao.getItemStockTotal();
		int rowCount = list.size();

		totalStockData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			stockdata.add(iVo);
		}

	}

	// �޺��ڽ� ���� �˻�
	public void handlerBtn_ItemStock_select_SearchActoion(ActionEvent event) {
		ArrayList<ItemStockVO> list;
		ItemStockVO iVo = null;
		ItemStockDAO iDao = null;
		Object[][] totalData = null;

		
		
		try {
			
			String searchName = "";
			boolean searchResult = false;
			
			searchName = cb_ItemStock_Main.getValue().toString();
			
			iDao = new ItemStockDAO();
			list = iDao.getItemStockCombo(searchName);
			if(list !=null) {
				stockdata.removeAll(stockdata);
				for (int i = 0; i < list.size(); i++) {
					iVo = list.get(i);
					stockdata.add(iVo);
				}
			}else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();
			}


		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ ���� �˻�����");
			alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();

		}
		

	}

	// ��ǰ�ڵ� �˻�
	public void handlerBtn_ItemStock_SearchActoion(ActionEvent event) {

		ItemStockVO iVo = new ItemStockVO();
		ItemStockDAO iDao = null;
		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txt_ItemStock_GoodsSearch.getText().trim();
			iDao = new ItemStockDAO();
			iVo = iDao.getItemStockCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText("��ǰ�ڵ��� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (iVo != null)) {
				ArrayList<String> title;
				ArrayList<ItemStockVO> list;

				title = iDao.getColumnName();
				int columnCount = title.size();

				list = iDao.getItemStockTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (iVo.getGoodsName().equals(searchName)) {
					txt_ItemInfo_Search.clear();
					stockdata.removeAll(stockdata);
					for (int index = 0; index < rowCount; index++) {
						iVo = list.get(index);
						if (iVo.getGoodsName().equals(searchName)) {
							stockdata.add(iVo);
							searchResult = true;

						}

					}
				}
			}
			if (!searchResult) {
				txt_ItemInfo_Search.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();

			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ ���� �˻�����");
			alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();

		}

	}

	// ��� ����â Ȱ��ȭ
	public void handlerBtn_ItemStock_EditActoion(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/View/itemStockEdit.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btn_ItemStock_Edit.getScene().getWindow());
			dialog.setTitle("����");
			Parent parentEdit = (Parent) loader.load();

			ItemStockVO stockGoods = tableView_ItemList.getSelectionModel().getSelectedItem();
			selectedIndex = tableView_ItemList.getSelectionModel().getSelectedIndex();

			Button btn_ItemStock_Edit_Ok = (Button) parentEdit.lookup("#btn_ItemStock_Edit_Ok");
			Button btn_ItemStock_Edit_Cancel = (Button) parentEdit.lookup("#btn_ItemStock_Edit_Cancel");

			TextField Editst_GoodsCode = (TextField) parentEdit.lookup("#txt_GoodsCode");
			TextField Editst_GoodsName = (TextField) parentEdit.lookup("#txt_GoodsName");
			TextField Editst_MainCategory = (TextField) parentEdit.lookup("#txt_MainCategory");
			TextField Editst_SubCategory = (TextField) parentEdit.lookup("#txt_SubCategory");
			TextField Editst_GoodsColor = (TextField) parentEdit.lookup("#txt_GoodsColor");
			TextField Editst_GoodsSize = (TextField) parentEdit.lookup("#txt_GoodsSize");
			TextField Editst_GoodsQuantity = (TextField) parentEdit.lookup("#txt_GoodsQuantity");
			TextField Editst_GoodsPrice = (TextField) parentEdit.lookup("#txt_GoodsPrice");
			TextField Editst_GoodsSalesPrice = (TextField) parentEdit.lookup("#txt_GoodsSalesPrice");
			// ���� ���� ����Ʈ ����

			// ���� �Ұ� �׸�
			Editst_GoodsCode.setDisable(true);
			Editst_GoodsName.setDisable(true);
			Editst_MainCategory.setDisable(true);
			Editst_SubCategory.setDisable(true);
			Editst_GoodsColor.setDisable(true);
			Editst_GoodsSize.setDisable(true);
			Editst_GoodsPrice.setDisable(true);
			Editst_GoodsSalesPrice.setDisable(true);

			Editst_GoodsCode.setText(stockGoods.getGoodsCode() + "");
			Editst_GoodsName.setText(stockGoods.getGoodsName());
			Editst_MainCategory.setText(stockGoods.getMainCategory());
			Editst_SubCategory.setText(stockGoods.getSubCategory());
			Editst_GoodsColor.setText(stockGoods.getGoodsColor() + "");
			Editst_GoodsSize.setText(stockGoods.getGoodsSize() + "");
			Editst_GoodsQuantity.setText(stockGoods.getGoodsQuantity() + "");
			Editst_GoodsPrice.setText(stockGoods.getGoodsPrice() + "");
			Editst_GoodsSalesPrice.setText(stockGoods.getGoodsSalesPrice() + "");

			// ���� ��ư �׸�
			btn_ItemStock_Edit_Ok.setOnAction(e -> {

				StockEdit_ListVO seVo = null;
				StockEdit_ListDAO seDao = null;

				TextField txt_GoodsCode = (TextField) parentEdit.lookup("#txt_GoodsCode");
				TextField txt_GoodsName = (TextField) parentEdit.lookup("#txt_GoodsName");
				TextField txt_MainCategory = (TextField) parentEdit.lookup("#txt_MainCategory");
				TextField txt_SubCategory = (TextField) parentEdit.lookup("#txt_SubCategory");
				TextField txt_GoodsColor = (TextField) parentEdit.lookup("#txt_GoodsColor");
				TextField txt_GoodsSize = (TextField) parentEdit.lookup("#txt_GoodsSize");
				TextField txt_GoodsQuantity = (TextField) parentEdit.lookup("#txt_GoodsQuantity");
				TextField txt_GoodsPrice = (TextField) parentEdit.lookup("#txt_GoodsPrice");
				TextField txt_GoodsSalesPrice = (TextField) parentEdit.lookup("#txt_GoodsSalesPrice");

				TextField txt_ItemStock_Edit_Code = (TextField) parentEdit.lookup("#txt_ItemStock_Edit_Code");
				TextField txt_ItemStock_Edit_Date = (TextField) parentEdit.lookup("#txt_ItemStock_Edit_Date");
				TextArea txt_ItemStock_Edit_Remarks = (TextArea) parentEdit.lookup("#txt_ItemStock_Edit_Remarks");

				data.remove(selectedIndex);

				try {

					seVo = new StockEdit_ListVO(Integer.parseInt(txt_ItemStock_Edit_Code.getText().trim()),
							txt_ItemStock_Edit_Date.getText(), Integer.parseInt(txt_GoodsCode.getText().trim()),
							txt_GoodsName.getText(), Integer.parseInt(txt_GoodsQuantity.getText().trim()),
							txt_ItemStock_Edit_Remarks.getText());
					seDao = new StockEdit_ListDAO();
					seDao.getStockEditregiste(seVo);

					stockdata.removeAll(stockdata);
					stockListdata.removeAll(stockListdata);
					data.removeAll(data);
					totalStockList();
					totalEditList();
					totalList();
					dialog.close();
				} catch (Exception e2) {
					e2.printStackTrace();

				}

			});

			// ���� ��� ��ư
			btn_ItemStock_Edit_Cancel.setOnAction(e -> {
				dialog.close();
			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (IOException e) {
			System.out.println(e.toString());
		} catch (Exception e) {

		}

	}

	// �߰� ����
	public void handlerBtn_ItemStock_Edit_AddActoion(MouseEvent event) {

		try {

			ItemStockDAO iDao = null;
			iDao = new ItemStockDAO();

			if (event.getClickCount() != 2) {

				iStockEdit_Edit_Code = tableView_StockEdit.getSelectionModel().getSelectedItem()
						.getStockEdit_Edit_Code();
				st_goodsCode = tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsCode();

				try {

					iDao.getItemStockListUpdate(iStockEdit_Edit_Code, st_goodsCode);

					StockEdit_List_AddVO seliVo = new StockEdit_List_AddVO();

					seliVo.setStockEdit_Edit_Add_Code(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Code());
					seliVo.setStockEdit_Add_Edit_Date(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Date());
					seliVo.setStockEdit_Add_GoodsCode(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsCode());
					seliVo.setStockEdit_Add_GoodsName(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsName());
					seliVo.setStockEdit_Add_GoodsQuantity(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsQuantity());
					seliVo.setStockEdit_Edit_Add_Remarks(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Remarks());

					iDao.getAdd_ItemStockList_List(seliVo);

					data.removeAll(data);
					stockList_Adddata.removeAll(stockList_Adddata);
					stockdata.removeAll(stockdata);
					stockListdata.removeAll(stockListdata);

					totalList();
					totalEditList();
					totalStockList();
					totalEditList_Add();

				} catch (Exception e1) {
					System.out.println("�԰� �̷� ��ư ���� ����" + e1);

				}

			}
			totalList();
		} catch (Exception e) {
		}

	}

	// ���� ����
	public void handlerBtn_ItemStock_Edit_DelActoion(MouseEvent event) {

		try {

			ItemStockDAO iDao = null;
			iDao = new ItemStockDAO();

			if (event.getClickCount() != 2) {

				iStockEdit_Edit_Code = tableView_StockEdit.getSelectionModel().getSelectedItem()
						.getStockEdit_Edit_Code();
				st_goodsCode = tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsCode();

				try {

					iDao.getItemStockList_DelUpdate(iStockEdit_Edit_Code, st_goodsCode);

					StockEdit_List_DelVO seliVo = new StockEdit_List_DelVO();

					seliVo.setStockEdit_Edit_Del_Code(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Code());
					seliVo.setStockEdit_Edit_Del_Date(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Date());
					seliVo.setStockEdit_Del_GoodsCode(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsCode());
					seliVo.setStockEdit_Del_GoodsName(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsName());
					seliVo.setStockEdit_Del_GoodsQuantity(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsQuantity());
					seliVo.setStockEdit_Edit_Del_Remarks(
							tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Remarks());

					iDao.getDel_ItemStockList_List(seliVo);

					data.removeAll(data);
					stockList_Deldata.removeAll(stockList_Deldata);
					stockList_Adddata.removeAll(stockList_Adddata);
					stockdata.removeAll(stockdata);
					stockListdata.removeAll(stockListdata);

					totalList();
					totalEditList();
					totalStockList();
					totalEditList_Add();
					totalEditList_Del();

				} catch (Exception e1) {
					System.out.println("�԰� �̷� ��ư ���� ����" + e1);

				}

			}
			totalList();
		} catch (Exception e) {
		}

	}

	// ������
	public void handlerBtn_ItemStock_Edit_CancelActoion(ActionEvent event) {
		ItemStockDAO stDao = null;
		stDao = new ItemStockDAO();

		iStockEdit_Edit_Code = tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_Edit_Code();
		st_goodsCode = tableView_StockEdit.getSelectionModel().getSelectedItem().getStockEdit_GoodsCode();

		try {
			stDao.getEditListDelete(iStockEdit_Edit_Code);
			stockListdata.removeAll(stockListdata);

			totalStockList();
			totalEditList();
			totalEditList_Add();
			totalEditList_Del();

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("��� ���� ��� ");
			alert.setHeaderText("��ǰ " + st_goodsCode + " �� ��� ������ ��� �Ǿ����ϴ�..");
			alert.setContentText("��� ����� Ȯ���ϼ���.");
			alert.showAndWait();

		} catch (Exception e) {

		}

	}

	// ��� ��� �ݱ�
	public void handlerBtn_ItemStock_ExitActoion(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btn_ItemInfo_Cancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}

	}

	// ��� ��� �ʱ�ȭ
	public void handlerBtn_ItemStock_ResetActoion(ActionEvent event) {
		// �׸� �°� ����
		stockListdata.removeAll(stockListdata);
		stockList_Deldata.removeAll(stockList_Deldata);
		stockList_Adddata.removeAll(stockList_Adddata);
		stockdata.removeAll(stockdata);

		totalStockList();
		totalEditList();
		totalEditList_Add();
		totalEditList_Del();
		txt_ItemStock_GoodsSearch.clear();
		cb_ItemStock_Main.getSelectionModel().clearSelection();
		/* cb_ItemStock_Sub.getSelectionModel().clearSelection(); */
	}

	// �� 2 ���� ��ǰ ����
	// ���
	public void handlerBtn_ItemInfo_AddActoion(ActionEvent event) {

		try {

			data.removeAll(data);
			stockdata.removeAll(stockdata);
			ItemInfoVO iVo = null;
			ItemInfoDAO iDao = null;
			ItemStockVO iVo_Stock = null;
			ItemStockDAO iDao_Stock = null;

			File dirMake = new File(dirSave.getAbsolutePath());

			if (!dirMake.exists()) {
				dirMake.mkdir();
			}
			String fileName = imageSave(selectedFile);

			iVo = new ItemInfoVO();
			iVo = new ItemInfoVO(Integer.parseInt(txt_GoodsCode.getText().trim()), txt_GoodsName.getText(),
					cb_MainCategory.getSelectionModel().getSelectedItem(),
					cb_SubCategory.getSelectionModel().getSelectedItem(),
					Integer.parseInt(txt_GoodsColor.getText().trim()), Integer.parseInt(txt_GoodsSize.getText().trim()),
					Integer.parseInt(txt_GoodsPrice.getText().trim()),
					Integer.parseInt(txt_GoodsSalesPrice.getText().trim()), txt_GoodsRemarks.getText(), fileName);
			iVo.setGoodsQuantity(0);

			iVo_Stock = new ItemStockVO();
			iVo_Stock = new ItemStockVO(Integer.parseInt(txt_GoodsCode.getText().trim()), txt_GoodsName.getText(),
					cb_MainCategory.getSelectionModel().getSelectedItem(),
					cb_SubCategory.getSelectionModel().getSelectedItem(),
					Integer.parseInt(txt_GoodsColor.getText().trim()), Integer.parseInt(txt_GoodsSize.getText().trim()),
					Integer.parseInt(txt_GoodsPrice.getText().trim()),
					Integer.parseInt(txt_GoodsSalesPrice.getText().trim()), txt_GoodsRemarks.getText(), fileName);
			iVo_Stock.setGoodsQuantity(0);

			iDao = new ItemInfoDAO();
			iDao.getItemInforegiste(iVo);

			iDao_Stock = new ItemStockDAO();
			iDao_Stock.getItemStockregiste(iVo_Stock);

			if (iDao != null) {
				totalList();
				totalStockList();

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ���� �Է�");
				alert.setHeaderText(txt_GoodsName.getText() + " ��ǰ�� ������ ���������� �߰��Ǿ����ϴ�..");
				alert.setContentText("���� ��ǰ ������ �Է��ϼ���");
				alert.showAndWait();

				// �⺻ �̹���
				localUrl = "/images/default.png";
				localImage = new Image(localUrl, false);
				imageView.setImage(localImage);

				handlerBtn_ItemInfo_ResetActoion(event);

			}

		} catch (Exception ie) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("��ǰ���� �Է�");
			alert.setHeaderText("��ǰ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();

		}

	}

	// ����
	public void handlerBtn_ItemInfo_EditActoion(ActionEvent event) {

		ItemInfoVO iVo = null;
		ItemInfoDAO iDao = null;
		ItemStockVO siVo = null;
		ItemStockDAO siDao = null;

		try {

			iVo = new ItemInfoVO(Integer.parseInt(txt_GoodsCode.getText().trim()), txt_GoodsName.getText(),
					cb_MainCategory.getSelectionModel().getSelectedItem(),
					cb_SubCategory.getSelectionModel().getSelectedItem(),
					Integer.parseInt(txt_GoodsColor.getText().trim()), Integer.parseInt(txt_GoodsSize.getText().trim()),
					Integer.parseInt(txt_GoodsPrice.getText().trim()),
					Integer.parseInt(txt_GoodsSalesPrice.getText().trim()), txt_GoodsRemarks.getText());

			siVo = new ItemStockVO(Integer.parseInt(txt_GoodsCode.getText().trim()), txt_GoodsName.getText(),
					cb_MainCategory.getSelectionModel().getSelectedItem(),
					cb_SubCategory.getSelectionModel().getSelectedItem(),
					Integer.parseInt(txt_GoodsColor.getText().trim()), Integer.parseInt(txt_GoodsSize.getText().trim()),
					Integer.parseInt(txt_GoodsPrice.getText().trim()),
					Integer.parseInt(txt_GoodsSalesPrice.getText().trim()), txt_GoodsRemarks.getText());

			iDao = new ItemInfoDAO();
			iDao.getItemInfoUpdate(iVo, iVo.getGoodsCode() + "");

			siDao = new ItemStockDAO();
			siDao.getItemStockUpdate(siVo, iVo.getGoodsCode() + "");
			data.removeAll(data);
			stockdata.removeAll(stockdata);
			totalList();
			totalStockList();

			txt_GoodsCode.setDisable(false);
			handlerBtn_ItemInfo_ResetActoion(event);

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� ���� ����");
			alert.setHeaderText("�����Ǵ� ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}

	}

	// ����
	public void handlerBtn_ItemInfo_DeleteActoion(ActionEvent event) {

		ItemInfoDAO iDao = null;
		iDao = new ItemInfoDAO();
		ItemStockDAO siDao = null;
		siDao = new ItemStockDAO();

		try {
			iDao.getItemInfoDelete(goodsCode);
			siDao.getItemStockDelete(goodsCode);
			data.removeAll(data);
			stockdata.removeAll(stockdata);
			totalList();
			totalStockList();

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	// �ʱ�ȭ
	public void handlerBtn_ItemInfo_ResetActoion(ActionEvent event) {

		txt_GoodsCode.clear();
		txt_GoodsName.clear();
		cb_MainCategory.getSelectionModel().clearSelection();
		cb_SubCategory.getSelectionModel().clearSelection();
		txt_GoodsColor.clear();
		txt_GoodsSize.clear();
		txt_GoodsPrice.clear();
		txt_GoodsSalesPrice.clear();
		txt_GoodsRemarks.clear();

		data.removeAll(data);
		totalList();
		txt_GoodsCode.setDisable(false);
		cb_SubCategory.setDisable(true);

	}

	// ����
	public void handlerBtn_ItemInfo_CancelActoion(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/main.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���θ޴�");
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btn_ItemInfo_Cancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {

		}

	}

	// �̹���
	public void handlerBtnImageFileActoion(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image File", "*.png", "*.jpg", "*.gif"));
		try {
			selectedFile = fileChooser.showOpenDialog(primaryStage);
			if (selectedFile != null) {
				// �̹��� ���� ���
				localUrl = selectedFile.toURI().toURL().toString();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		localImage = new Image(localUrl, false);
		imageView.setImage(localImage);
		imageView.setFitHeight(250);
		imageView.setFitWidth(230);
		if (selectedFile != null) {
			selectFileName = selectedFile.getName();
		}

	}

	// ���� â
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	/***********************************************************
	 * imageDelete() �̹��� ���� �޼ҵ�.
	 *
	 * @param (������
	 *            ���ϸ�)
	 * @return �������θ� ����
	 ***********************************************************/
	public boolean imageDelete(String fileName) {
		boolean result = false;
		try {
			File fileDelete = new File(dirSave.getAbsolutePath() + "\\" + fileName); // �����̹��� ����
			if (fileDelete.exists() && fileDelete.isFile()) {
				result = fileDelete.delete();
				// �⺻ �̹���
				localUrl = "/image/default.png";
				localImage = new Image(localUrl, false);
				imageView.setImage(localImage);
			}
		} catch (Exception ie) {
			System.out.println("ie = [ " + ie.getMessage() + "]");
			result = false;
		}

		return result;
	}

	/***********************************************************
	 * imageSave() �̹��� ���� �޼ҵ�.
	 *
	 * @param (�о��
	 *            ���� ��ü)
	 ***********************************************************/
	public String imageSave(File file) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		int data = -1;
		String fileName = null;
		try {
			// �̹��� ���ϸ� ����
			fileName = "Goods" + System.currentTimeMillis() + "_" + file.getName();
			bis = new BufferedInputStream(new FileInputStream(file));
			bos = new BufferedOutputStream(new FileOutputStream(dirSave.getAbsolutePath() + "\\" + fileName));
			// ������ �̹��� ���� InputStream�� �������� �̸����� ���� -1
			while ((data = bis.read()) != -1) {
				bos.write(data);
				bos.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (IOException e) {
				e.getMessage();
			}

		}
		return fileName;
	}

	// �˻�
	public void handlerBtn_ItemInfo_SearchActoion(ActionEvent event) {

		ItemInfoVO iVo = new ItemInfoVO();
		ItemInfoDAO iDao = null;
		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txt_ItemInfo_Search.getText().trim();
			iDao = new ItemInfoDAO();
			iVo = iDao.getItemInfoCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText("��ǰ�ڵ��� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (iVo != null)) {
				ArrayList<String> title;
				ArrayList<ItemInfoVO> list;

				title = iDao.getColumnName();
				int columnCount = title.size();

				list = iDao.getItemInfoTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (iVo.getGoodsName().equals(searchName)) {
					txt_ItemInfo_Search.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						iVo = list.get(index);
						if (iVo.getGoodsName().equals(searchName)) {
							data.add(iVo);
							searchResult = true;

						}

					}
				}
			}
			if (!searchResult) {
				txt_ItemInfo_Search.clear();
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText(searchName + " ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���.");
				alert.showAndWait();

			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ ���� �˻�����");
			alert.setHeaderText("�˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();

		}

	}

	// ��ǰ���� ��ü ����Ʈ
	public void totalList() {
		Object[][] totalData;

		ItemInfoDAO iDao = new ItemInfoDAO();
		ItemInfoVO iVo = null;
		ArrayList<String> title;
		ArrayList<ItemInfoVO> list;

		title = iDao.getColumnName();
		int columnCount = title.size();

		list = iDao.getItemInfoTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			data.add(iVo);
		}

	}

	// ���� ���� ��ü ����Ʈ
	public void totalEditList() {
		Object[][] totalData;

		StockEdit_ListDAO seDao = new StockEdit_ListDAO();
		StockEdit_ListVO seVo = null;
		ArrayList<String> title;
		ArrayList<StockEdit_ListVO> list;

		title = seDao.getColumnName();
		int columnCount = title.size();

		list = seDao.getStockEditTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			seVo = list.get(index);
			stockListdata.add(seVo);
		}

	}

	// ���� ���� �߰� ��ü ����Ʈ
	public void totalEditList_Add() {
		Object[][] totalData;

		ItemStockDAO seDao = new ItemStockDAO();
		StockEdit_List_AddVO seVo = null;
		ArrayList<String> title;
		ArrayList<StockEdit_List_AddVO> list;

		title = seDao.getColumnName();
		int columnCount = title.size();

		list = seDao.getAddItemStockTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			seVo = list.get(index);
			stockList_Adddata.add(seVo);
		}
	}

	// ���� ���� ���� ��ü ����Ʈ
	public void totalEditList_Del() {
		Object[][] totalData;

		ItemStockDAO seDao = new ItemStockDAO();
		StockEdit_List_DelVO seVo = null;
		ArrayList<String> title;
		ArrayList<StockEdit_List_DelVO> list;

		title = seDao.getColumnName();
		int columnCount = title.size();

		list = seDao.getDelItemStockTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			seVo = list.get(index);
			stockList_Deldata.add(seVo);
		}
	}
}
