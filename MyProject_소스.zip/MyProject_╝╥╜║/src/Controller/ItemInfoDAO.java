package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ItemInfoVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ItemInfoDAO {
	// �⺻ �����
	public ItemInfoVO getItemInforegiste(ItemInfoVO iVo) throws Exception {
		String dml = "insert into ItemInfo" + "(in_goodsCode, in_goodsName, in_mainCategory, in_subCategory, in_goodsColor,"
				+ " in_goodsSize, in_goodsQuantity, in_goodsPrice, in_goodsSalesPrice, in_goodsRemarks, in_filename) " + "values"
				+ "( ?,?,?,?,?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		ItemInfoVO retval = null;
		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, iVo.getGoodsCode());
			pstmt.setString(2, iVo.getGoodsName());
			pstmt.setString(3, iVo.getMainCategory());
			pstmt.setString(4, iVo.getSubCategory());
			pstmt.setInt(5, iVo.getGoodsColor());
			pstmt.setInt(6, iVo.getGoodsSize());
			pstmt.setInt(7, iVo.getGoodsQuantity());
			pstmt.setInt(8, iVo.getGoodsPrice());
			pstmt.setInt(9, iVo.getGoodsSalesPrice());
			pstmt.setString(10, iVo.getGoodsRemarks());
			pstmt.setString(11, iVo.getFilename());

			int i = pstmt.executeUpdate();

			retval = new ItemInfoVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}
		}

		return retval;
	}

	// ��ǰ���� ��ü ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<ItemInfoVO> getItemStockTotal() {
		ArrayList<ItemInfoVO> ItemStock_list = new ArrayList<ItemInfoVO>();
		String tml = "select * from itemInfo";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ItemInfoVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new ItemInfoVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	// ��ǰ���� ��ü ����Ʈ (��ǰ ��Ϻκ�)
	public ArrayList<ItemInfoVO> getItemInfoTotal() {
		ArrayList<ItemInfoVO> ItemInfo_list = new ArrayList<ItemInfoVO>();
		String tml = "select * from itemInfo ";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ItemInfoVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new ItemInfoVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11));
				ItemInfo_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemInfo_list;
	}

	// �����ͺ��̽����� ��ǰ���� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from ItemInfo";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ������ ��ǰ������ ����
	public ItemInfoVO getItemInfoUpdate(ItemInfoVO iVo, String goodsCode) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update ItemInfo set"
				+ " in_goodsName=?, in_mainCategory=?, in_subCategory=?, in_goodsColor=?, in_goodsSize=?, in_goodsPrice=?, in_goodsSalesPrice=?, in_goodsRemarks=?, in_filename=? where in_goodsCode=?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ItemInfoVO retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);

			pstmt.setString(1, iVo.getGoodsName());
			pstmt.setString(2, iVo.getMainCategory());
			pstmt.setString(3, iVo.getSubCategory());
			pstmt.setInt(4, iVo.getGoodsColor());
			pstmt.setInt(5, iVo.getGoodsSize());
			pstmt.setInt(6, iVo.getGoodsPrice());
			pstmt.setInt(7, iVo.getGoodsSalesPrice());
			pstmt.setString(8, iVo.getGoodsRemarks());
			pstmt.setString(9, iVo.getFilename());
			pstmt.setInt(10, iVo.getGoodsCode());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� �Ϸ�.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
				retval = new ItemInfoVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� ����.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}
		}
		return retval;
	}

	
	// �˻� �� ����
		
	public ItemInfoVO getItemInfoCheck(String goodsCode) throws Exception {
		String dml = "select * from ItemInfo where in_goodsCode = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		ItemInfoVO sVo = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, goodsCode);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				sVo = new ItemInfoVO();
				sVo.setGoodsCode(rs.getInt("in_goodsCode"));
				sVo.setGoodsName(rs.getString("in_goodsName"));
				sVo.setGoodsColor(rs.getInt("in_goodsColor"));
				sVo.setGoodsSize(rs.getInt("in_goodsSize"));
				sVo.setGoodsPrice(rs.getInt("in_goodsPrice"));
				sVo.setGoodsSalesPrice(rs.getInt("in_goodsSalesPrice"));
				sVo.setGoodsRemarks(rs.getString("in_goodsRemarks"));
				sVo.setFilename(rs.getString("in_filename"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();
			} catch (SQLException se) {
			}
		}
		return sVo;
	}

	// ��ǰ���� ����
	public void getItemInfoDelete(int searchCode) throws Exception {
		String dml = "delete from itemInfo where in_goodsCode= ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, searchCode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� �Ϸ�.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ���� ����");
				alert.setHeaderText("��ǰ ���� ���� ����.");
				alert.setContentText("��ǰ ���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}
	}

}
