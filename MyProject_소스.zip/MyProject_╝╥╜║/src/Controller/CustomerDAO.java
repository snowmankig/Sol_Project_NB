package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.CustomerVO;
import Model.OrderVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

//�������� ����
public class CustomerDAO {
	public CustomerVO getCustomerregiste(CustomerVO cVo) throws Exception {
		String dml = "insert into customerInfo"
				+ "(customerCode, customerName, customerAge, customerGender, customerTel, customerEmail, customerRemarks)"
				+ "values" + "( ?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		CustomerVO retval = null;

		try {
			// DBUtil�̶�� Ŭ������ getConnection() �ż���� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, cVo.getCustomerCode());
			pstmt.setString(2, cVo.getCustomerName());
			pstmt.setString(3, cVo.getCustomerAge());
			pstmt.setString(4, cVo.getCustomerGender());
			pstmt.setString(5, cVo.getCustomerTel());
			pstmt.setString(6, cVo.getCustomerEmail());
			pstmt.setString(7, cVo.getCustomerRemarks()); // ����� �߰� 11.7

			int i = pstmt.executeUpdate();

			retval = new CustomerVO();

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}

		}
		return retval;
	}

	// ������ dlfma�� �޾� ������ȸ
	public CustomerVO getCustomerCheck(String customerName) throws Exception {
		String dml = "select customerCode, customerName, customerAge, customerGender, customerTel, customerEmail, customerRemarks from customerInfo where customerName=?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CustomerVO retval = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, customerName);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				retval = new CustomerVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7));
			}

		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}

		}
		return retval;

	}

	// ������ü ����Ʈ
	public ArrayList<CustomerVO> getCustomerTotal() {
		ArrayList<CustomerVO> list = new ArrayList<CustomerVO>();
		String tml = "select * from customerInfo";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CustomerVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new CustomerVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7));
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return list;
	}

	// �����ͺ��̽����� ���� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from customerInfo";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ������ ���������� ����
	public CustomerVO getCustomerUpdate(CustomerVO cvo, int customerCode) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update customerInfo set"
				+ " customerName=?, customerAge=?, customerGender=?, customerTel=?, customerEmail=?, customerRemarks=? where customerCode=?";
		Connection con = null;
		PreparedStatement pstmt = null;
		CustomerVO retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, cvo.getCustomerName());
			pstmt.setString(2, cvo.getCustomerAge());
			pstmt.setString(3, cvo.getCustomerGender());
			pstmt.setString(4, cvo.getCustomerTel());
			pstmt.setString(5, cvo.getCustomerEmail());
			pstmt.setString(6, cvo.getCustomerRemarks());
			pstmt.setInt(7, customerCode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ���� �Ϸ�.");
				alert.setContentText("�������� ���� ����!!!");
				alert.showAndWait();
				retval = new CustomerVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ���� ����.");
				alert.setContentText("�������� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}
		}
		return retval;
	}

	public void getCustomerDelete(int customerCode) throws Exception {
		String dml = "delete from customerInfo where customerCode = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, customerCode);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ���� �Ϸ�.");
				alert.setContentText("�������� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ְ������� ����");
				alert.setHeaderText("�������� ���� ����.");
				alert.setContentText("�������� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}

	}
}
