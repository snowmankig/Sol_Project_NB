package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.AdminVO;

public class LoginDAO {

	public AdminVO getLoginIdSearch(String adminID) throws Exception {
		String dml = "select * from adminInfo where adminId = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdminVO aVo = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, adminID);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				aVo = new AdminVO();
				aVo.setAdminID(rs.getString("adminID"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();

			} catch (Exception e) {
			}

		}
		return aVo;
	}

	public AdminVO getLoginPWSearch(String adminPW) throws Exception {
		String dml = "select * from adminInfo where adminPW = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdminVO aVo = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, adminPW);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				aVo = new AdminVO();
				aVo.setAdminPW(rs.getString("adminPW"));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}

		}
		return aVo;
	}

	public void getTotalLogin(String adminID, String adminPW) throws Exception {

		String dml = "select * from adminInfo where adminID = ? and adminPW = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdminVO aVo = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, adminID);
			pstmt.setString(2, adminPW);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				aVo = new AdminVO();
				aVo.setAdminID(rs.getString("adminID"));
				aVo.setAdminPW(rs.getString("adminPW"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}

		}
		return;
	}
}
