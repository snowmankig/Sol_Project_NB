package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import Model.ItemStockVO;
import Model.OrderVO;
import Model.SalesVO;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class SalesDAO {

	// �Ǹ� �⺻ ���� ����
	public SalesVO getSalesregiste(SalesVO sVo) throws Exception {
		String dml = "insert into salesInfo"
				+ "(sales_Date, sales_Code, sales_GoodsCode, sales_GoodsName, sales_GoodsQuantity , sales_GoodsSalesPrice, sales_GoodsRemarks)"
				+ "values" + "( ?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		SalesVO retval = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, sVo.getSales_Date());
			pstmt.setInt(2, sVo.getSales_Code());
			pstmt.setInt(3, sVo.getSales_GoodsCode());
			pstmt.setString(4, sVo.getSales_GoodsName());
			pstmt.setInt(5, sVo.getSales_GoodsQuantity());
			pstmt.setInt(6, sVo.getSales_GoodsSalesPrice());
			pstmt.setString(7, sVo.getSales_GoodsRemarks());
			int i = pstmt.executeUpdate();

			retval = new SalesVO();

		} catch (SQLException e) {

			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}

		}
		return retval;
	}

	// �Ǹ� ��ü ����Ʈ Ȯ�ο�
	public ArrayList<SalesVO> getSalesTotal() {
		ArrayList<SalesVO> list = new ArrayList<SalesVO>();
		String tml = "select * from salesInfo";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SalesVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new SalesVO(rs.getDate(1) + "", rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getString(7));
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return list;
	}

	// �����ͺ��̽����� �ֹ� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from salesInfo";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e2) {
			}
		}
		return columnName;
	}

	// ������ �ֹ������� ����
	public OrderVO getOrderUpdate(SalesVO svo, int sales_Code) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update salesInfo set"
				+ " sales_GoodsQuantity=?, sales_GoodsSalesPrice=?, sales_GoodsRemarks=? where sales_Code=?";
		Connection con = null;
		PreparedStatement pstmt = null;
		OrderVO retval = null;

		try {

			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, svo.getSales_GoodsQuantity());
			pstmt.setInt(2, svo.getSales_GoodsSalesPrice());
			pstmt.setString(3, svo.getSales_GoodsRemarks());
			pstmt.setInt(4, sales_Code);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ����");
				alert.setHeaderText("�Ǹ� ���� �Ϸ�.");
				alert.setContentText("�Ǹ� ���� ����!!!");
				alert.showAndWait();
				retval = new OrderVO();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ����");
				alert.setHeaderText("�Ǹ� ���� ����.");
				alert.setContentText("�Ǹ� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}
		}
		return retval;
	}

	// �ֹ� ����
	public void getSalesDelete(int sales_Code) throws Exception {
		String dml = "delete from salesInfo where sales_Code = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, sales_Code);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ���");
				alert.setHeaderText("�Ǹ� ��� �Ϸ�.");
				alert.setContentText("�Ǹ� ��� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�Ǹ� ���");
				alert.setHeaderText("�Ǹ� ��� ����.");
				alert.setContentText("�Ǹ� ��� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println("e=[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");

		} finally {
			try {

				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
			}

		}

	}

	// �˻� �� ���� ���� ����
	public SalesVO getSalesCheck(String sales_GoodsName) throws Exception {
		String dml = "select * from salesInfo where sales_GoodsName = ?";
		Connection con = null;
		PreparedStatement pstmt = null;

		ResultSet rs = null;
		SalesVO sVo = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, sales_GoodsName);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				sVo = new SalesVO();
				sVo.setSales_Date(rs.getString("sales_Date"));
				sVo.setSales_Code(rs.getInt("sales_Code"));
				sVo.setSales_GoodsCode(rs.getInt("sales_GoodsCode"));
				sVo.setSales_GoodsName(rs.getString("sales_GoodsName"));
				sVo.setSales_GoodsQuantity(rs.getInt("sales_GoodsQuantity"));
				sVo.setSales_GoodsSalesPrice(rs.getInt("sales_GoodsSalesPrice"));
				sVo.setSales_GoodsRemarks(rs.getString("sales_GoodsRemarks"));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)

					con.close();
			} catch (SQLException se) {
			}
		}
		return sVo;
	}

	// ��ǰ���� ��ü ����Ʈ (��ǰ ��ü ����Ʈ)
	public ArrayList<ItemStockVO> getItemStockTotal() {
		ArrayList<ItemStockVO> ItemStock_list = new ArrayList<ItemStockVO>();
		String tml = "select * from itemStock";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ItemStockVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new ItemStockVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11));
				ItemStock_list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {
			}
		}
		return ItemStock_list;
	}

	public void salesItem_Add_ItemStock(int sales_Code, int st_goodsCode) {
		StringBuffer sql = new StringBuffer();

		// ��� ���̺� ����� ����� �Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity - sales_GoodsQuantity ");

		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, salesInfo ");

		// ��ǰ �ڵ�(���) ��ǰ �ڵ�(�Ǹ�) �ֹ���ȣ
		sql.append(" where st_goodsCode = sales_GoodsCode and sales_Code =?)");

		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode =? ");

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			pstmt.setInt(1, sales_Code);
			pstmt.setInt(2, st_goodsCode);

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}

	public void salesItem_Delete_ItemStock(int sales_Code, int st_goodsCode) {
		StringBuffer sql = new StringBuffer();

		// ��� ���̺� ����� ����� �Ǹŷ�
		sql.append(" update itemStock set st_goodsQuantity = (select st_goodsQuantity + sales_GoodsQuantity ");

		// ��� ���̺�, �ֹ����̺�
		sql.append(" from itemStock, salesInfo ");

		// ��ǰ �ڵ�(���) ��ǰ �ڵ�(�Ǹ�) �ֹ���ȣ
		sql.append(" where st_goodsCode = sales_GoodsCode and sales_Code =?)");

		// ��ǰ ��ȣ
		sql.append(" where st_goodsCode =? ");

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			pstmt.setInt(1, sales_Code);
			pstmt.setInt(2, st_goodsCode);

			int i = pstmt.executeUpdate();

		} catch (SQLException se) {
			System.out.println("�԰���� ������ ����� ���� sql������" + se);
		} catch (Exception e) {
			System.out.println("�԰������� ����� ���� �������" + e);
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException se) {

			}

		}
	}

}