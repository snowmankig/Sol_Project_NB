package Model;

public class OrderVO {
	private String order_Date; // �ֹ�����
	private int  order_Code; // �ֹ��ڵ�
	private int order_GoodsCode; //��ǰ�ڵ�
	private String order_GoodsName; //��ǰ ��
	private int order_GoodsQuantity; //��ǰ����
	private int order_GoodsPrice; //��ǰ �ܰ�
	private String order_GoodsRemarks; //���
	
	public OrderVO() {
		super();
	}

	public OrderVO(String order_Date, int order_Code, int order_GoodsCode, String order_GoodsName,
			int order_GoodsQuantity, int order_GoodsPrice, String order_GoodsRemarks) {
		super();
		this.order_Date = order_Date;
		this.order_Code = order_Code;
		this.order_GoodsCode = order_GoodsCode;
		this.order_GoodsName = order_GoodsName;
		this.order_GoodsQuantity = order_GoodsQuantity;
		this.order_GoodsPrice = order_GoodsPrice;
		this.order_GoodsRemarks = order_GoodsRemarks;
	}
	
	

	public OrderVO(int order_GoodsQuantity, int order_GoodsPrice) {
		super();
		this.order_GoodsQuantity = order_GoodsQuantity;
		this.order_GoodsPrice = order_GoodsPrice;
	}
	
	public OrderVO(int order_Code) {
		super();
		this.order_Code = order_Code;
	}
	
	

	public String getOrder_Date() {
		return order_Date;
	}

	public void setOrder_Date(String order_Date) {
		this.order_Date = order_Date;
	}

	public int getOrder_Code() {
		return order_Code;
	}

	public void setOrder_Code(int order_Code) {
		this.order_Code = order_Code;
	}

	public int getOrder_GoodsCode() {
		return order_GoodsCode;
	}

	public void setOrder_GoodsCode(int order_GoodsCode) {
		this.order_GoodsCode = order_GoodsCode;
	}

	public String getOrder_GoodsName() {
		return order_GoodsName;
	}

	public void setOrder_GoodsName(String order_GoodsName) {
		this.order_GoodsName = order_GoodsName;
	}

	public int getOrder_GoodsQuantity() {
		return order_GoodsQuantity;
	}

	public void setOrder_GoodsQuantity(int order_GoodsQuantity) {
		this.order_GoodsQuantity = order_GoodsQuantity;
	}

	public int getOrder_GoodsPrice() {
		return order_GoodsPrice;
	}

	public void setOrder_GoodsPrice(int order_GoodsPrice) {
		this.order_GoodsPrice = order_GoodsPrice;
	}

	public String getOrder_GoodsRemarks() {
		return order_GoodsRemarks;
	}

	public void setOrder_GoodsRemarks(String order_GoodsRemarks) {
		this.order_GoodsRemarks = order_GoodsRemarks;
	}
	
	
	
	

}
