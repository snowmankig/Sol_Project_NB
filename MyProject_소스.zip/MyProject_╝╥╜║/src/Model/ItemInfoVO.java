package Model;

public class ItemInfoVO {

	private int goodsCode;
	private String goodsName;
	private String mainCategory;
	private String subCategory;
	private int goodsColor;
	private int goodsSize;
	private int goodsQuantity;
	private int goodsPrice;
	private int goodsSalesPrice;
	private String goodsRemarks;
	private String filename = null;
	
	
	public ItemInfoVO() {
		super();
	}


	public ItemInfoVO(int goodsCode, String goodsName, String mainCategory, String subCategory, int goodsColor,
			int goodsSize, int goodsQuantity, int goodsPrice, int goodsSalesPrice, String goodsRemarks,
			String filename) {
		super();
		this.goodsCode = goodsCode;
		this.goodsName = goodsName;
		this.mainCategory = mainCategory;
		this.subCategory = subCategory;
		this.goodsColor = goodsColor;
		this.goodsSize = goodsSize;
		this.goodsQuantity = goodsQuantity;
		this.goodsPrice = goodsPrice;
		this.goodsSalesPrice = goodsSalesPrice;
		this.goodsRemarks = goodsRemarks;
		this.filename = filename;
	}
	
	


	public ItemInfoVO(int goodsCode, String goodsName, String mainCategory, String subCategory, int goodsColor,
			int goodsSize, int goodsPrice, int goodsSalesPrice, String goodsRemarks) {
		super();
		this.goodsCode = goodsCode;
		this.goodsName = goodsName;
		this.mainCategory = mainCategory;
		this.subCategory = subCategory;
		this.goodsColor = goodsColor;
		this.goodsSize = goodsSize;
		this.goodsPrice = goodsPrice;
		this.goodsSalesPrice = goodsSalesPrice;
		this.goodsRemarks = goodsRemarks;
	}
	

		
		
	public ItemInfoVO(int goodsCode, String goodsName, String mainCategory, String subCategory, int goodsColor,
				int goodsSize, int goodsPrice, int goodsSalesPrice, String goodsRemarks, String filename) {
			super();
			this.goodsCode = goodsCode;
			this.goodsName = goodsName;
			this.mainCategory = mainCategory;
			this.subCategory = subCategory;
			this.goodsColor = goodsColor;
			this.goodsSize = goodsSize;
			this.goodsPrice = goodsPrice;
			this.goodsSalesPrice = goodsSalesPrice;
			this.goodsRemarks = goodsRemarks;
			this.filename = filename;
		}


	public int getGoodsCode() {
		return goodsCode;
	}


	public void setGoodsCode(int goodsCode) {
		this.goodsCode = goodsCode;
	}


	public String getGoodsName() {
		return goodsName;
	}


	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}


	public String getMainCategory() {
		return mainCategory;
	}


	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}


	public String getSubCategory() {
		return subCategory;
	}


	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}


	public int getGoodsColor() {
		return goodsColor;
	}


	public void setGoodsColor(int goodsColor) {
		this.goodsColor = goodsColor;
	}


	public int getGoodsSize() {
		return goodsSize;
	}


	public void setGoodsSize(int goodsSize) {
		this.goodsSize = goodsSize;
	}


	public int getGoodsQuantity() {
		return goodsQuantity;
	}


	public void setGoodsQuantity(int goodsQuantity) {
		this.goodsQuantity = goodsQuantity;
	}


	public int getGoodsPrice() {
		return goodsPrice;
	}


	public void setGoodsPrice(int goodsPrice) {
		this.goodsPrice = goodsPrice;
	}


	public int getGoodsSalesPrice() {
		return goodsSalesPrice;
	}


	public void setGoodsSalesPrice(int goodsSalesPrice) {
		this.goodsSalesPrice = goodsSalesPrice;
	}


	public String getGoodsRemarks() {
		return goodsRemarks;
	}


	public void setGoodsRemarks(String goodsRemarks) {
		this.goodsRemarks = goodsRemarks;
	}


	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	

}
