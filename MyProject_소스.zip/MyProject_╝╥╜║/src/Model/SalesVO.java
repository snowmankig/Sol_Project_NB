package Model;

public class SalesVO {
	
	private String sales_Date; // �ֹ�����
	private int  sales_Code; // �ֹ��ڵ�
	private int sales_GoodsCode; //��ǰ�ڵ�
	private String sales_GoodsName; //��ǰ ��
	private int sales_GoodsQuantity; //��ǰ����
	private int sales_GoodsSalesPrice; //�Ǹ� �ܰ�
	private String sales_GoodsRemarks; //���
	
	
	
	public SalesVO() {
		super();
	}



	public SalesVO(String sales_Date, int sales_Code, int sales_GoodsCode, String sales_GoodsName,
			int sales_GoodsQuantity, int sales_GoodsSalesPrice, String sales_GoodsRemarks) {
		super();
		this.sales_Date = sales_Date;
		this.sales_Code = sales_Code;
		this.sales_GoodsCode = sales_GoodsCode;
		this.sales_GoodsName = sales_GoodsName;
		this.sales_GoodsQuantity = sales_GoodsQuantity;
		this.sales_GoodsSalesPrice = sales_GoodsSalesPrice;
		this.sales_GoodsRemarks = sales_GoodsRemarks;
	}

	
	


	public String getSales_Date() {
		return sales_Date;
	}



	public void setSales_Date(String sales_Date) {
		this.sales_Date = sales_Date;
	}



	public int getSales_Code() {
		return sales_Code;
	}



	public void setSales_Code(int sales_Code) {
		this.sales_Code = sales_Code;
	}



	public int getSales_GoodsCode() {
		return sales_GoodsCode;
	}



	public void setSales_GoodsCode(int sales_GoodsCode) {
		this.sales_GoodsCode = sales_GoodsCode;
	}



	public String getSales_GoodsName() {
		return sales_GoodsName;
	}



	public void setSales_GoodsName(String sales_GoodsName) {
		this.sales_GoodsName = sales_GoodsName;
	}



	public int getSales_GoodsQuantity() {
		return sales_GoodsQuantity;
	}



	public void setSales_GoodsQuantity(int sales_GoodsQuantity) {
		this.sales_GoodsQuantity = sales_GoodsQuantity;
	}



	public int getSales_GoodsSalesPrice() {
		return sales_GoodsSalesPrice;
	}



	public void setSales_GoodsSalesPrice(int sales_GoodsSalesPrice) {
		this.sales_GoodsSalesPrice = sales_GoodsSalesPrice;
	}



	public String getSales_GoodsRemarks() {
		return sales_GoodsRemarks;
	}



	public void setSales_GoodsRemarks(String sales_GoodsRemarks) {
		this.sales_GoodsRemarks = sales_GoodsRemarks;
	}
	
	
	
	
	
	
	
	

}
