package Model;

public class StockEdit_ListVO {

	int stockEdit_Edit_Code;// ���� �ڵ�
	String stockEdit_Edit_Date; // ���� �Ⱓ
	int stockEdit_GoodsCode; // ���� ��ǰ �ڵ�
	String stockEdit_GoodsName; // ���� ��ǰ ��
	int stockEdit_GoodsQuantity; // ���� ��ǰ ����
	String stockEdit_Edit_Remarks; // ���� ����

	public StockEdit_ListVO() {
		super();
	}

	public StockEdit_ListVO(int stockEdit_Edit_Code, String stockEdit_Edit_Date, int stockEdit_GoodsCode,
			String stockEdit_GoodsName, int stockEdit_GoodsQuantity, String stockEdit_Edit_Remarks) {
		super();
		this.stockEdit_Edit_Code = stockEdit_Edit_Code;
		this.stockEdit_Edit_Date = stockEdit_Edit_Date;
		this.stockEdit_GoodsCode = stockEdit_GoodsCode;
		this.stockEdit_GoodsName = stockEdit_GoodsName;
		this.stockEdit_GoodsQuantity = stockEdit_GoodsQuantity;
		this.stockEdit_Edit_Remarks = stockEdit_Edit_Remarks;
	}

	public int getStockEdit_Edit_Code() {
		return stockEdit_Edit_Code;
	}

	public void setStockEdit_Edit_Code(int stockEdit_Edit_Code) {
		this.stockEdit_Edit_Code = stockEdit_Edit_Code;
	}

	public String getStockEdit_Edit_Date() {
		return stockEdit_Edit_Date;
	}

	public void setStockEdit_Edit_Date(String stockEdit_Edit_Date) {
		this.stockEdit_Edit_Date = stockEdit_Edit_Date;
	}

	public int getStockEdit_GoodsCode() {
		return stockEdit_GoodsCode;
	}

	public void setStockEdit_GoodsCode(int stockEdit_GoodsCode) {
		this.stockEdit_GoodsCode = stockEdit_GoodsCode;
	}

	public String getStockEdit_GoodsName() {
		return stockEdit_GoodsName;
	}

	public void setStockEdit_GoodsName(String stockEdit_GoodsName) {
		this.stockEdit_GoodsName = stockEdit_GoodsName;
	}

	public int getStockEdit_GoodsQuantity() {
		return stockEdit_GoodsQuantity;
	}

	public void setStockEdit_GoodsQuantity(int stockEdit_GoodsQuantity) {
		this.stockEdit_GoodsQuantity = stockEdit_GoodsQuantity;
	}

	public String getStockEdit_Edit_Remarks() {
		return stockEdit_Edit_Remarks;
	}

	public void setStockEdit_Edit_Remarks(String stockEdit_Edit_Remarks) {
		this.stockEdit_Edit_Remarks = stockEdit_Edit_Remarks;
	}

	
	
	
}