package Model;

public class StockEdit_List_AddVO {

	int stockEdit_Edit_Add_Code;// ���� �ڵ�
	String stockEdit_Add_Edit_Date; // ���� �Ⱓ
	int stockEdit_Add_GoodsCode; // ���� ��ǰ �ڵ�
	String stockEdit_Add_GoodsName; // ���� ��ǰ ��
	int stockEdit_Add_GoodsQuantity; // ���� ��ǰ ����
	String stockEdit_Edit_Add_Remarks; // ���� ����
	
	
	public StockEdit_List_AddVO() {
		super();
	}


	public StockEdit_List_AddVO(int stockEdit_Edit_Add_Code, String stockEdit_Add_Edit_Date,
			int stockEdit_Add_GoodsCode, String stockEdit_Add_GoodsName, int stockEdit_Add_GoodsQuantity,
			String stockEdit_Edit_Add_Remarks) {
		super();
		this.stockEdit_Edit_Add_Code = stockEdit_Edit_Add_Code;
		this.stockEdit_Add_Edit_Date = stockEdit_Add_Edit_Date;
		this.stockEdit_Add_GoodsCode = stockEdit_Add_GoodsCode;
		this.stockEdit_Add_GoodsName = stockEdit_Add_GoodsName;
		this.stockEdit_Add_GoodsQuantity = stockEdit_Add_GoodsQuantity;
		this.stockEdit_Edit_Add_Remarks = stockEdit_Edit_Add_Remarks;
	}


	public int getStockEdit_Edit_Add_Code() {
		return stockEdit_Edit_Add_Code;
	}


	public void setStockEdit_Edit_Add_Code(int stockEdit_Edit_Add_Code) {
		this.stockEdit_Edit_Add_Code = stockEdit_Edit_Add_Code;
	}


	public String getStockEdit_Add_Edit_Date() {
		return stockEdit_Add_Edit_Date;
	}


	public void setStockEdit_Add_Edit_Date(String stockEdit_Add_Edit_Date) {
		this.stockEdit_Add_Edit_Date = stockEdit_Add_Edit_Date;
	}


	public int getStockEdit_Add_GoodsCode() {
		return stockEdit_Add_GoodsCode;
	}


	public void setStockEdit_Add_GoodsCode(int stockEdit_Add_GoodsCode) {
		this.stockEdit_Add_GoodsCode = stockEdit_Add_GoodsCode;
	}


	public String getStockEdit_Add_GoodsName() {
		return stockEdit_Add_GoodsName;
	}


	public void setStockEdit_Add_GoodsName(String stockEdit_Add_GoodsName) {
		this.stockEdit_Add_GoodsName = stockEdit_Add_GoodsName;
	}


	public int getStockEdit_Add_GoodsQuantity() {
		return stockEdit_Add_GoodsQuantity;
	}


	public void setStockEdit_Add_GoodsQuantity(int stockEdit_Add_GoodsQuantity) {
		this.stockEdit_Add_GoodsQuantity = stockEdit_Add_GoodsQuantity;
	}


	public String getStockEdit_Edit_Add_Remarks() {
		return stockEdit_Edit_Add_Remarks;
	}


	public void setStockEdit_Edit_Add_Remarks(String stockEdit_Edit_Add_Remarks) {
		this.stockEdit_Edit_Add_Remarks = stockEdit_Edit_Add_Remarks;
	}


	
	
}