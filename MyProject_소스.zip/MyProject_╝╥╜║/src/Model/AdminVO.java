package Model;

public class AdminVO {
	private int no;
	private String fc_Code;
	private String adminID;
	private String adminPW;
	private String adminPWT;
	private String adminName;
	private String adminTel;
	private String adminPhone;

	public AdminVO() {
		super();
	}

	public AdminVO(int no, String fc_Code, String adminID, String adminPW, String adminPWT, String adminName,
			String adminTel, String adminPhone) {
		super();
		this.no = no;
		this.fc_Code = fc_Code;
		this.adminID = adminID;
		this.adminPW = adminPW;
		this.adminPWT = adminPWT;
		this.adminName = adminName;
		this.adminTel = adminTel;
		this.adminPhone = adminPhone;
	}

	public AdminVO(String fc_Code, String adminID, String adminPW, String adminPWT, String adminName, String adminTel,
			String adminPhone) {
		super();
		this.fc_Code = fc_Code;
		this.adminID = adminID;
		this.adminPW = adminPW;
		this.adminPWT = adminPWT;
		this.adminName = adminName;
		this.adminTel = adminTel;
		this.adminPhone = adminPhone;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getFc_Code() {
		return fc_Code;
	}

	public void setFc_Code(String franchisee) {
		this.fc_Code = franchisee;
	}

	public String getAdminID() {
		return adminID;
	}

	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}

	public String getAdminPW() {
		return adminPW;
	}

	public void setAdminPW(String adminPW) {
		this.adminPW = adminPW;
	}

	public String getAdminPWT() {
		return adminPWT;
	}

	public void setAdminPWT(String adminPWT) {
		this.adminPWT = adminPWT;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminTel() {
		return adminTel;
	}

	public void setAdminTel(String adminTel) {
		this.adminTel = adminTel;
	}

	public String getAdminPhone() {
		return adminPhone;
	}

	public void setAdminPhone(String adminPhone) {
		this.adminPhone = adminPhone;
	}

}