package Model;

public class StockEdit_List_DelVO {

	int stockEdit_Edit_Del_Code;// ���� �ڵ�
	String stockEdit_Edit_Del_Date; // ���� �Ⱓ
	int stockEdit_Del_GoodsCode; // ���� ��ǰ �ڵ�
	String stockEdit_Del_GoodsName; // ���� ��ǰ ��
	int stockEdit_Del_GoodsQuantity; // ���� ��ǰ ����
	String stockEdit_Edit_Del_Remarks; // ���� ����

	public StockEdit_List_DelVO() {
		super();
	}

	public StockEdit_List_DelVO(int stockEdit_Edit_Del_Code, String stockEdit_Edit_Del_Date,
			int stockEdit_Del_GoodsCode, String stockEdit_Del_GoodsName, int stockEdit_Del_GoodsQuantity,
			String stockEdit_Edit_Del_Remarks) {
		super();
		this.stockEdit_Edit_Del_Code = stockEdit_Edit_Del_Code;
		this.stockEdit_Edit_Del_Date = stockEdit_Edit_Del_Date;
		this.stockEdit_Del_GoodsCode = stockEdit_Del_GoodsCode;
		this.stockEdit_Del_GoodsName = stockEdit_Del_GoodsName;
		this.stockEdit_Del_GoodsQuantity = stockEdit_Del_GoodsQuantity;
		this.stockEdit_Edit_Del_Remarks = stockEdit_Edit_Del_Remarks;
	}

	public int getStockEdit_Edit_Del_Code() {
		return stockEdit_Edit_Del_Code;
	}

	public void setStockEdit_Edit_Del_Code(int stockEdit_Edit_Del_Code) {
		this.stockEdit_Edit_Del_Code = stockEdit_Edit_Del_Code;
	}

	public String getStockEdit_Edit_Del_Date() {
		return stockEdit_Edit_Del_Date;
	}

	public void setStockEdit_Edit_Del_Date(String stockEdit_Edit_Del_Date) {
		this.stockEdit_Edit_Del_Date = stockEdit_Edit_Del_Date;
	}

	public int getStockEdit_Del_GoodsCode() {
		return stockEdit_Del_GoodsCode;
	}

	public void setStockEdit_Del_GoodsCode(int stockEdit_Del_GoodsCode) {
		this.stockEdit_Del_GoodsCode = stockEdit_Del_GoodsCode;
	}

	public String getStockEdit_Del_GoodsName() {
		return stockEdit_Del_GoodsName;
	}

	public void setStockEdit_Del_GoodsName(String stockEdit_Del_GoodsName) {
		this.stockEdit_Del_GoodsName = stockEdit_Del_GoodsName;
	}

	public int getStockEdit_Del_GoodsQuantity() {
		return stockEdit_Del_GoodsQuantity;
	}

	public void setStockEdit_Del_GoodsQuantity(int stockEdit_Del_GoodsQuantity) {
		this.stockEdit_Del_GoodsQuantity = stockEdit_Del_GoodsQuantity;
	}

	public String getStockEdit_Edit_Del_Remarks() {
		return stockEdit_Edit_Del_Remarks;
	}

	public void setStockEdit_Edit_Del_Remarks(String stockEdit_Edit_Del_Remarks) {
		this.stockEdit_Edit_Del_Remarks = stockEdit_Edit_Del_Remarks;
	}

}