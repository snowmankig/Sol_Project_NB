package Model;

public class CustomerVO {
	private int customerCode; // �����ڵ�
	private String customerName; // �����̸�
	private String customerAge; // ��������	
	private String customerGender; // ���� ���� - ��Ʈ�� �Է� ( ���� �޺��ڽ��� ����)
	private String customerTel; // ������ȣ
	private String customerEmail; // ���� �̸���
	private String customerRemarks;// 11.7 ��� �߰�
	
	
	public CustomerVO() {
		super();
	}


	public CustomerVO(int customerCode, String customerName, String customerAge, String customerGender,
			String customerTel, String customerEmail, String customerRemarks) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAge = customerAge;
		this.customerGender = customerGender;
		this.customerTel = customerTel;
		this.customerEmail = customerEmail;
		this.customerRemarks = customerRemarks;
	}

	public CustomerVO(String customerName, String customerAge, String customerGender, String customerTel,
			String customerEmail, String customerRemarks) {
		super();
		this.customerName = customerName;
		this.customerAge = customerAge;
		this.customerGender = customerGender;
		this.customerTel = customerTel;
		this.customerEmail = customerEmail;
		this.customerRemarks = customerRemarks;
	}


	public CustomerVO(String customerName) {
		super();
		this.customerName = customerName;
	}


	public int getCustomerCode() {
		return customerCode;
	}


	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerAge() {
		return customerAge;
	}


	public void setCustomerAge(String customerAge) {
		this.customerAge = customerAge;
	}


	public String getCustomerGender() {
		return customerGender;
	}


	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}


	public String getCustomerTel() {
		return customerTel;
	}


	public void setCustomerTel(String customerTel) {
		this.customerTel = customerTel;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public String getCustomerRemarks() {
		return customerRemarks;
	}


	public void setCustomerRemarks(String customerRemarks) {
		this.customerRemarks = customerRemarks;
	} 
	
	
	
}